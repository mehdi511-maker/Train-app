#!/usr/bin/env python3
"""Parse the official 'اعمال تغییرات برنامه قطارهای مسافری' letter (converted to
text) into structured JSON items.

Usage: python parse_changes.py letter.txt out.json
"""
import json
import re
import sys

DIG = {ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")}
DIG.update({ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")})
YEAR = 1405
MONTH_DAYS = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29]


def clean(s):
    s = s.translate(DIG).replace("ي", "ی").replace("ك", "ک")
    return re.sub(r"\s+", " ", s).strip()


def add_days(y, m, d, k):
    d += k
    while d > MONTH_DAYS[m - 1]:
        d -= MONTH_DAYS[m - 1]
        m += 1
        if m > 12:
            m, y = 1, y + 1
    return y, m, d


def fmt(y, m, d):
    return f"{y:04d}/{m:02d}/{d:02d}"


def date_lists(t):
    """'27و19و13و05/08/1405' -> explicit dates (works for several groups)."""
    out = []
    for grp, mon, yr in re.findall(r"((?:\d{1,2}\s*و\s*)*\d{1,2})\s*/\s*(\d{2})\s*/\s*(\d{4})", t):
        for d in re.split(r"\s*و\s*", grp):
            out.append(fmt(int(yr), int(mon), int(d)))
    return out


def period_dates(t):
    """'از مورخه 05/08/1405 لغایت 29/08/1405 بصورت شش روز یکبار' -> dates."""
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})\s*لغایت\s*(\d{2})/(\d{2})/(\d{4})", t)
    if not m:
        return None
    d1, m1, y1, d2, m2, y2 = map(int, m.groups())
    if re.search(r"یکروز در میان|یک روز در میان", t):
        step = 2
    else:
        w = {"دو": 2, "سه": 3, "چهار": 4, "چهارروز": 4, "پنج": 5, "شش": 6, "هفت": 7, "هشت": 8}
        mm = re.search(r"(دو|سه|چهار|پنج|شش|هفت|هشت)\s*روز\s*یکبار", t)
        step = w[mm.group(1)] if mm else None
    if step is None:
        return None
    end = fmt(y2, m2, d2)
    y, mo, d = y1, m1, d1
    out = []
    while fmt(y, mo, d) <= end:
        out.append(fmt(y, mo, d))
        y, mo, d = add_days(y, mo, d, step)
    return out, step, fmt(y1, m1, d1), end


def main(src, out):
    text = open(src, encoding="utf-8").read()
    body = text[text.index("1."):text.index("رونوشت")]
    chunks = re.split(r"(?m)^\s*(\d{1,2})\.\s+", body)
    items = []
    for i in range(1, len(chunks), 2):
        no, raw = int(chunks[i]), clean(chunks[i + 1])
        raw = re.sub(r"\s*جعفر زیاری.*$", "", raw)
        raw = re.sub(r"[+|\-]{5,}.*$", "", raw).strip()
        trains = re.findall(r"قطار\s+(.+?)\s*\(\s*(\d{3})\s*[-–]?\s*([^)]*)\)", raw)
        if no == 32:  # دو قطار در یک بند
            trains = [("مشهد سرخس", "936", ""), ("مشهد سرخس", "938", "")]
        if not trains:
            m = re.search(r"قطار\s+(.+?)\s*\((\d{3})", raw)
            trains = [(m.group(1), m.group(2), "")] if m else []
        item = dict(no=no, text=raw)
        for route, number, op in trains[:1]:
            item["route"] = route.strip()
            item["train"] = number
            if op.strip():
                item["operator"] = op.strip()
        if no == 32:
            item["train"] = "936"
            item["also"] = ["938"]
        item["direction"] = "outbound" if "فقط در مسیر رفت" in raw else "both"
        p = period_dates(raw)
        dl = date_lists(raw)
        if "حذف" in raw and "ادامه سیر" not in raw:
            item["kind"] = "cancel"
        elif "ادامه سیر" in raw:
            item["kind"] = "extend"
        elif "اعزام گردد" in raw and "ساعت" in raw and "بجای ساعت" in raw:
            item["kind"] = "retime"
        elif "از ایستگاه قم" in raw:
            item["kind"] = "origin_change"
        elif "سازمان" in raw:
            item["kind"] = "formation"
        else:
            item["kind"] = "other"
        if p and item["kind"] == "cancel":
            dates, step, a, b = p
            extra = [d for d in dl if d not in dates and not (a <= d <= b and False)]
            # تاریخ‌های تکی بعد از «و نیز» که خارج از بازه هستند
            tail = raw.split("لغایت", 1)[1]
            extra = [d for d in date_lists(tail.split("بصورت", 1)[-1])]
            item["period"] = dict(from_=a, to=b, every=step)
            item["dates"] = sorted(set(dates + extra))
        else:
            item["dates"] = dl[: len(dl)] if item["kind"] != "retime" else dl
        if item["kind"] == "retime":
            ts = re.findall(r"(\d{1,2}:\d{2})", raw)
            if len(ts) >= 2:
                item["old_time"], item["new_time"] = ts[0], ts[1]
        items.append(item)
    items.sort(key=lambda x: x["no"])
    for it in items:
        if "period" in it:
            it["period"]["from"] = it["period"].pop("from_")
    json.dump(items, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for it in items:
        print(it["no"], it.get("train"), it.get("route"), "|", it.get("operator"), "|", it["kind"],
              it["direction"], len(it["dates"]), it["dates"][:3], it.get("period"), it.get("old_time"), it.get("new_time"))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
