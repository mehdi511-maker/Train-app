# ابزارهای ساخت داده (پایتون)

ترتیب ساخت `timetables.json` از فایل‌های رسمی:

1. جدول‌ها از فایل‌های اکسل (هر برگه یک جفت قطار):
   `python parse_xlsx.py timetables_from_xlsx.json Attch_1.xlsx Attch_2.xlsx`
   (نیاز: `pip install openpyxl`)
2. نامه‌ی تغییرات (فایل Word را اول به متن تبدیل کنید، مثلاً با LibreOffice/pandoc):
   `python parse_changes.py letter.txt changes_items.json`
3. ادغام (جدول راهبری داخل خود `build_dataset.py` به‌صورت دستی نوشته شده؛ هر فصل ویرایشش کنید):
   `python build_dataset.py` ← `timetables.json`

بعد از ساخت:
- فایل را در `assets/timetables.json` بگذارید.
- در `assets/version.json` مقدار `valid_to` را برابر بزرگ‌ترین `valid_to` جدول‌ها و `data_version` را **یکی بالاتر** بگذارید (برای هر ویرایش داده، حتی بدون تغییر تاریخ انقضا).
