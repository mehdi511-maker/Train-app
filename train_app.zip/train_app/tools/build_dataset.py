import json
tt=json.load(open('timetables_from_xlsx.json',encoding='utf-8'))
items=json.load(open('changes_items.json',encoding='utf-8'))
M='مبداء - مقصد'; B='مرز به مرز'; K='کمربندی'
ops_pairs={
 '524':[('اصفهان',B,'تهران تا اصفهان'),('فارس',B,'شیراز تا اصفهان')],
 '526':[('اصفهان',B,'تهران تا اصفهان'),('فارس',B,'شیراز تا اصفهان')],
 '532':[('هرمزگان',M,None)],
 '620':[('یزد',M,None)],
 '622':[('اصفهان',B,'تهران تا کاشان'),('یزد',B,'یزد تا کاشان')],
 '720':[('یزد',B,'تهران تا بافق'),('کرمان',B,'بافق تا کرمان')],
 '724':[('اصفهان',B,None),('کرمان',B,'یزد تا فهرج'),('جنوب شرق',B,'زاهدان تا فهرج')],
 '728':[('جنوب شرق',B,None)],
 '738':[('جنوب شرق',B,None)],
 '820':[('هرمزگان',M,None)],
 '822':[('اصفهان',B,'تهران تا یزد'),('هرمزگان',B,'بندرعباس تا یزد')],
 '356':[('خاور شرق',M,None)],
 '358':[('خاور شرق',M,None)],
 '586':[('فارس',B,'شیراز تا طبس'),('خاور شرق',K,'طبس تا تربت حیدریه'),('خراسان',K,'مشهد تا تربت حیدریه')],
 '680':[('یزد',M,None)],
 '682':[('یزد',M,None)],
 '780':[('خاور شرق',K,'رام جوپار، مبارکه تا مشهد'),('یزد',K,'یک روز در میان، مبارکه تا طبس'),('کرمان',K,'کرمان تا مبارکه'),('شرق',K,'رام بنیاد، مبارکه تا مشهد')],
 '880':[('یزد',K,None),('هرمزگان',K,'بندرعباس تا بافق'),('شرق',K,'مبارکه تا مشهد')],
 '974':[('خاور شرق',K,'مشهد تا طبس'),('خراسان',K,'مشهد تا تربت حیدریه')],
}
operations={}
nums={t['trains'][0]['number'] for t in tt['timetables']}
assert nums==set(ops_pairs), (nums^set(ops_pairs))
for t in tt['timetables']:
    a,b=t['trains'][0]['number'],t['trains'][1]['number']
    entries=[dict(region=r,mode=m,**({'section':s} if s else {})) for r,m,s in ops_pairs[a]]
    operations[a]=entries; operations[b]=entries
last=max(d for it in items for d in it['dates'])
out=dict(schema_version=2,data_version=2,timetables=tt['timetables'],
  operations_meta=dict(title='نحوه راهبری قطارهای مسافری در پاییز 1405',valid_from='1405/08/01',valid_to='1405/08/30',
     note='راهبری قطارهای فوق العاده که در فهرست نمی باشد به صورت مرز به مرز می باشد و راهبری ترن ست و ریل باس هایی که در فهرست نمی باشد بعهده شرکت حمل ونقل ریلی رجا می باشد.'),
  operations=operations,
  changes=dict(title='اعمال تغییرات برنامه قطارهای مسافری پاییز و زمستان 1405 (آبان ماه)',
     request='درخواست شماره 2508 مورخ 1405/07/25 اداره کل برنامه ریزی و نظارت بر خدمات مسافری',
     valid_to=last,items=items))
json.dump(out,open('timetables.json','w',encoding='utf-8'),ensure_ascii=False,separators=(',',':'))
import os; print(os.path.getsize('final.json')//1024,'KB','timetables',len(out['timetables']),'ops keys',len(operations),'changes',len(items),'last date',last)
