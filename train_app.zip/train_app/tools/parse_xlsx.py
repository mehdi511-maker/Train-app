#!/usr/bin/env python3
"""Convert the official Raja timetable workbooks (one sheet per train pair,
two directions side by side) into one JSON file (schema_version 2).

Usage: python parse_xlsx.py out.json Attch_1.xlsx [Attch_2.xlsx ...]
Needs: pip install openpyxl
"""
import json
import re
import sys
import datetime as dt

import openpyxl

ZWNJ = "\u200c"
JOINS = (("اسلام شهر", "اسلام" + ZWNJ + "شهر"), ("علی آباد", "علی" + ZWNJ + "آباد"),
         ("جلال آباد", "جلال" + ZWNJ + "آباد"), ("ده آباد", "ده" + ZWNJ + "آباد"),
         ("وبرنامه", "و برنامه"))
DIG = {ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")}
DIG.update({ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")})


def clean(s):
    if s is None:
        return None
    s = str(s).translate(DIG).replace("ي", "ی").replace("ك", "ک").replace("ھ", "ه")
    s = s.replace("\xa0", " ")
    return re.sub(r"[ \t]+", " ", s).strip()


def join_name(s):
    for a, b in JOINS:
        s = s.replace(a, b)
    return s


def hhmm(v):
    if isinstance(v, (dt.datetime, dt.time)):
        return f"{v.hour:02d}:{v.minute:02d}"
    if isinstance(v, str) and re.fullmatch(r"\s*\d{1,2}:\d{2}\s*", v):
        h, m = v.strip().split(":")
        return f"{int(h):02d}:{m}"
    return None


def to_min(t):
    h, m = t.split(":")
    return int(h) * 60 + int(m)


def num(v):
    if isinstance(v, bool) or v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return int(v)
    m = re.fullmatch(r"\s*(\d+)\s*", str(v).translate(DIG))
    return int(m.group(1)) if m else None


SPEEDS = {30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150}


def speed(v):
    """-> (max_speed, raw). Two values in one cell (e.g. '100/120', or the digits
    typed together as 100120) -> max + raw."""
    if v is None or v == "":
        return None, None
    n = num(v)
    if n is not None:
        if n in SPEEDS or n < 200:
            return n, None
        d = str(n)
        for i in (2, 3):
            a, b = d[:i], d[i:]
            if a.isdigit() and b.isdigit() and int(a) in SPEEDS and int(b) in SPEEDS:
                return max(int(a), int(b)), f"{a}/{b}"
        return n, None
    s = clean(v)
    nums = [int(x) for x in re.findall(r"\d+", s)]
    if len(nums) == 2:
        return max(nums), f"{nums[0]}/{nums[1]}"
    return None, s


def parse_sheet(ws, problems):
    title = clean(ws["H2"].value) or ""
    dates = [clean(c.value).strip('"') for c in ws[2]
             if isinstance(c.value, str) and re.search(r"\d{4}/\d\d/\d\d", c.value.translate(DIG))]
    nums = (num(ws["D3"].value), num(ws["K3"].value))
    if None in nums:
        return None
    days = (clean(ws["G3"].value) or "", clean(ws["N3"].value) or "")
    # rows: station rows have a name in C or K; segment rows sit between them
    rows = {"A": [], "B": []}
    segs = {"A": [], "B": []}
    last_station_row = 0
    r = 5
    while r <= ws.max_row:
        cn, kn = ws.cell(r, 3).value, ws.cell(r, 11).value
        is_station = (cn or kn) and (
            isinstance(ws.cell(r, 2).value, (int, float))
            or any(hhmm(ws.cell(r, c).value) for c in (6, 8, 14, 16)))
        if is_station:
            last_station_row = r
            for key, (cname, ccol) in (("A", (cn, 3)), ("B", (kn, 11))):
                if cname is None:
                    continue
                arr = hhmm(ws.cell(r, ccol + 3).value)
                dep = hhmm(ws.cell(r, ccol + 5).value)
                stop = num(ws.cell(r, ccol + 4).value)
                kmo = num(ws.cell(r, 2).value) if key == "A" else None
                rows[key].append(dict(raw=clean(cname), arrival=arr, stop_min=stop,
                                      departure=dep, km_official=kmo))
        elif last_station_row and (num(ws.cell(r, 5).value) is not None
                                   or num(ws.cell(r, 13).value) is not None):
            sa, sb = speed(ws.cell(r, 4).value), speed(ws.cell(r, 12).value)
            segs["A"].append(dict(minutes=num(ws.cell(r, 5).value), sp=sa))
            segs["B"].append(dict(minutes=num(ws.cell(r, 13).value), sp=sb,
                                  km=num(ws.cell(r, 10).value)))
        r += 1
    # legends: cells like '3-تلاقی' below the last station row; columns <=8 belong to A
    legend = {"A": {}, "B": {}}
    for row in ws.iter_rows(min_row=last_station_row + 1):
        if any(isinstance(c.value, str) and clean(c.value).startswith("توجه") for c in row):
            break  # بعد از «توجه:» دیگر پاورقی نیست
        for c in row:
            if isinstance(c.value, str):
                m = re.match(r"^\s*(\d+)\s*-\s*(.+)$", c.value.translate(DIG), flags=re.S)
                if m and not clean(c.value).startswith("توجه"):
                    key = "A" if c.column <= 8 else "B"
                    legend[key][m.group(1)] = join_name(clean(m.group(2)))
    return dict(title=title, dates=dates, numbers=nums, days=days, rows=rows,
                segs=segs, legend=legend, sheet=ws.title)


def split_name(raw):
    """'اسلام شهر 1' -> ('اسلام شهر', '1'); 'اضطراری 6' -> whole name, no note."""
    if raw.startswith("اضطراری"):
        return join_name(re.sub(r"\s+", " ", raw)), None
    m = re.match(r"^(.*?)\s*(\d+)$", raw)
    if m and m.group(1):
        return join_name(m.group(1).strip()), m.group(2)
    return join_name(raw), None


def build(p, problems):
    A, B = p["rows"]["A"], p["rows"]["B"]
    n = len(A)
    tag = f"{p['numbers'][0]}/{p['numbers'][1]}"
    if len(B) != n:
        problems.append(f"{tag}: station count differs A={n} B={len(B)}")
    if len(p["segs"]["A"]) != n - 1 or len(p["segs"]["B"]) != n - 1:
        problems.append(f"{tag}: segment count A={len(p['segs']['A'])} B={len(p['segs']['B'])} stations {n}")
    for key, stops in (("A", A), ("B", B)):
        for st in stops:
            st["station"], note = split_name(st.pop("raw"))
            st["note"] = p["legend"][key].get(note, note) if note else None
    for i in range(min(n, len(B))):
        if len(B) == n and A[i]["station"] != B[n - 1 - i]["station"]:
            problems.append(f"{tag}: name mismatch #{i + 1}: {A[i]['station']} | {B[n - 1 - i]['station']}")
    # official km: the A column; B direction gets it reversed
    for i, st in enumerate(B):
        st["km_official"] = A[n - 1 - i]["km_official"] if n - 1 - i < len(A) else None
    real = [s["km"] for s in p["segs"]["B"]]  # real distances are given on the B side
    trains = []
    for key, stops, seg_km in (("A", A, real[::-1]), ("B", B, real)):
        cum = 0
        for i, st in enumerate(stops):
            st["seq"] = i + 1
            seg = None
            if i < len(p["segs"][key]):
                s = p["segs"][key][i]
                ms, raw = s["sp"]
                seg = dict(minutes=s["minutes"], max_speed=ms,
                           km=seg_km[i] if i < len(seg_km) else None)
                if raw:
                    seg["max_speed_raw"] = raw
            st["km"] = cum
            if seg and seg.get("km") is not None:
                cum += seg["km"]
            st["segment_to_next"] = seg
            if i == 0:
                st["arrival"] = None
            if i == len(stops) - 1:
                st["departure"] = None
        for i in range(len(stops) - 1):
            a, b = stops[i], stops[i + 1]
            if a["departure"] and b["arrival"] and a["segment_to_next"]:
                calc = (to_min(b["arrival"]) - to_min(a["departure"])) % 1440
                if calc != a["segment_to_next"]["minutes"]:
                    problems.append(f"{tag}: minutes fixed {a['station']}->{b['station']}: "
                                    f"{a['segment_to_next']['minutes']}->{calc}")
                    a["segment_to_next"]["minutes"] = calc
        idx = 0 if key == "A" else 1
        trains.append(dict(number=str(p["numbers"][idx]), days=p["days"][idx],
                           **{"from": stops[0]["station"], "to": stops[-1]["station"]},
                           stops=stops))
    return dict(title=p["title"], sheet=p["sheet"],
                valid_from=p["dates"][0] if p["dates"] else None,
                valid_to=p["dates"][-1] if p["dates"] else None, trains=trains)


def main(out, files):
    result = {"schema_version": 2, "timetables": []}
    problems = []
    page = 0
    for f in files:
        wb = openpyxl.load_workbook(f, data_only=True)
        for ws in wb:
            p = parse_sheet(ws, problems)
            if p is None:
                print("skip sheet", repr(ws.title))
                continue
            tt = build(p, problems)
            page += 1
            tt["page"] = page
            result["timetables"].append(tt)
            t = tt["trains"]
            print(f"{page:2d} {t[0]['number']}/{t[1]['number']} {t[0]['from']} -> {t[0]['to']} "
                  f"| {len(t[0]['stops'])} stops | {tt['valid_from']}..{tt['valid_to']} | {t[0]['days']} / {t[1]['days']}")
    for q in problems:
        print("  -", q)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:])
