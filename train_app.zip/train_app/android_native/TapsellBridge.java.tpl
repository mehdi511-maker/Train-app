package __PKG__;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicBoolean;

import io.flutter.plugin.common.MethodChannel;
import ir.tapsell.plus.*;
import ir.tapsell.plus.model.*;

/** پل Flutter به تبلیغ ویدئویی بین‌صفحه‌ای Tapsell Plus. */
public class TapsellBridge {
    private static final String TAG = "TapsellBridge";
    private final Activity activity;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean initialized = false;
    private boolean adInProgress = false;

    public TapsellBridge(Activity activity) {
        this.activity = activity;
    }

    /** مقداردهی SDK؛ امضای initialize در نسخه‌های مختلف با reflection سازگار می‌شود. */
    public boolean init(String key) {
        try {
            Method with2 = null, with3 = null;
            for (Method m : TapsellPlus.class.getMethods()) {
                if (!m.getName().equals("initialize")) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length >= 2 && p[0].isAssignableFrom(activity.getClass())
                        && p[1] == String.class) {
                    if (p.length == 2) with2 = m;
                    else if (p.length == 3) with3 = m;
                }
            }
            if (with2 != null) {
                with2.invoke(null, activity, key);
            } else if (with3 != null) {
                Class<?> listenerClass = with3.getParameterTypes()[2];
                Object listener = null;
                if (listenerClass.isInterface()) {
                    listener = Proxy.newProxyInstance(
                        listenerClass.getClassLoader(),
                        new Class<?>[]{listenerClass},
                        new InvocationHandler() {
                            @Override
                            public Object invoke(Object proxy, Method method, Object[] args) {
                                Log.d(TAG, "Tapsell init callback: " + method.getName());
                                Class<?> r = method.getReturnType();
                                if (r == boolean.class) return false;
                                if (r == int.class) return 0;
                                if (r == long.class) return 0L;
                                return null;
                            }
                        });
                }
                with3.invoke(null, activity, key, listener);
            } else {
                Log.e(TAG, "TapsellPlus.initialize not found");
                return false;
            }
            initialized = true;
            return true;
        } catch (Throwable t) {
            Log.e(TAG, "Tapsell init failed", t);
            initialized = false;
            return false;
        }
    }

    /**
     * درخواست و نمایش تبلیغ. نتیجه‌ی Flutter فقط پس از بسته‌شدن تبلیغ یا خطا
     * برگردانده می‌شود. اگر درخواست در ۲۰ ثانیه پاسخ ندهد، ورود آزاد می‌شود.
     */
    public void showInterstitial(final String zone, final MethodChannel.Result result) {
        if (zone == null || zone.trim().isEmpty() || !initialized) {
            result.success(false);
            return;
        }

        synchronized (this) {
            if (adInProgress) {
                result.success(false);
                return;
            }
            adInProgress = true;
        }

        final AtomicBoolean completed = new AtomicBoolean(false);
        final Runnable finish = new Runnable() {
            @Override
            public void run() {
                if (!completed.compareAndSet(false, true)) return;
                synchronized (TapsellBridge.this) {
                    adInProgress = false;
                }
                result.success(false);
            }
        };

        // اگر دریافت آگهی معطل شد، بدون تبلیغ وارد بخش شو.
        handler.postDelayed(finish, 20000);

        try {
            TapsellPlus.requestInterstitialAd(activity, zone, new AdRequestCallback() {
                @Override
                public void response(TapsellPlusAdModel model) {
                    super.response(model);
                    if (completed.get()) return;
                    handler.removeCallbacks(finish);
                    final String responseId = model == null ? null : model.getResponseId();
                    if (responseId == null || responseId.isEmpty()) {
                        handler.post(finish);
                        return;
                    }

                    // مهلت جداگانه برای حالتی که SDK آگهی را گرفته اما نمایش کامل نمی‌شود.
                    handler.postDelayed(finish, 90000);
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (completed.get()) return;
                            try {
                                TapsellPlus.showInterstitialAd(activity, responseId,
                                    new AdShowListener() {
                                        @Override
                                        public void onOpened(TapsellPlusAdModel ad) {
                                            super.onOpened(ad);
                                            // از این لحظه زمان انتظار درخواست دیگر اعمال نمی‌شود.
                                            handler.removeCallbacks(finish);
                                        }

                                        @Override
                                        public void onClosed(TapsellPlusAdModel ad) {
                                            super.onClosed(ad);
                                            completeAfterAd();
                                        }

                                        @Override
                                        public void onError(TapsellPlusErrorModel error) {
                                            super.onError(error);
                                            Log.e(TAG, "Interstitial show error: " + error);
                                            completeAfterAd();
                                        }

                                        private void completeAfterAd() {
                                            if (!completed.compareAndSet(false, true)) return;
                                            handler.removeCallbacks(finish);
                                            synchronized (TapsellBridge.this) {
                                                adInProgress = false;
                                            }
                                            result.success(true);
                                        }
                                    });
                            } catch (Throwable t) {
                                Log.e(TAG, "Interstitial show failed", t);
                                handler.removeCallbacks(finish);
                                handler.post(finish);
                            }
                        }
                    });
                }

                @Override
                public void error(@androidx.annotation.NonNull String message) {
                    Log.e(TAG, "Interstitial request error: " + message);
                    handler.removeCallbacks(finish);
                    handler.post(finish);
                }
            });
        } catch (Throwable t) {
            Log.e(TAG, "Interstitial request failed", t);
            handler.removeCallbacks(finish);
            handler.post(finish);
        }
    }
}
