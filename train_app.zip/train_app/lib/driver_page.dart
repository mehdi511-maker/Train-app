import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'ads.dart';
import 'driver.dart';
import 'info_widgets.dart';
import 'models.dart';
import 'settings.dart';

class DriverPage extends StatefulWidget {
  final Train train;
  final AppSettings settings;
  final Dataset ds;
  const DriverPage(
      {super.key,
      required this.train,
      required this.settings,
      required this.ds});

  @override
  State<DriverPage> createState() => _DriverPageState();
}

class _DriverPageState extends State<DriverPage> {
  late final Timeline? tl = Timeline.build(widget.train);
  Timer? _timer;
  double delay = 0; // دقیقه
  int dayOffset = 0;
  bool keepAwake = true;
  late final Widget _table = Column(children: [
    ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 300),
      child: SingleChildScrollView(
        child: Column(children: [
          ChangesCard(train: widget.train, ds: widget.ds),
          OpsCard(train: widget.train, ds: widget.ds),
        ]),
      ),
    ),
    Expanded(child: RouteTable(train: widget.train)),
  ]);

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
    _wake(true);
    Ads.hideBanner(); // در صفحه‌ی لکوموتیورانی تبلیغ نیست
  }

  @override
  void dispose() {
    _timer?.cancel();
    _wake(false);
    Ads.showBanner();
    super.dispose();
  }

  Future<void> _wake(bool on) async {
    try {
      if (on) {
        await WakelockPlus.enable();
      } else {
        await WakelockPlus.disable();
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.train;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('لکوموتیورانی • قطار ${t.number}'),
          bottom: const TabBar(tabs: [
            Tab(text: 'جدول مسیر'),
            Tab(text: 'کابین'),
          ]),
        ),
        body: TabBarView(children: [
          _table,
          tl == null
              ? const Center(child: Text('ساعت‌های این قطار کامل نیست'))
              : _cab(context, tl!),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- کابین

  Widget _cab(BuildContext context, Timeline tl) {
    final dark = widget.settings.cabAlwaysDark;
    final base = Theme.of(context);
    final theme = dark
        ? ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            colorSchemeSeed: Colors.teal,
            fontFamily: base.textTheme.bodyMedium?.fontFamily)
        : base;
    return Theme(
      data: theme,
      child: Builder(builder: (context) {
        final cs = Theme.of(context).colorScheme;
        final now = DateTime.now();
        final delta = scheduleDelta(tl, now, dayOffset);
        final a = analyze(tl, delta, delay);
        final st = tl.train.stops;
        final maxDay = tl.total ~/ 1440;
        return Container(
          color: dark ? Colors.black : null,
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              if (maxDay > 0) ...[
                Wrap(spacing: 8, children: [
                  const Text('روز سفر:'),
                  for (var d = 0; d <= maxDay; d++)
                    ChoiceChip(
                        label: Text('${d + 1}'),
                        selected: dayOffset == d,
                        onSelected: (_) => setState(() => dayOffset = d)),
                ]),
                const SizedBox(height: 8),
              ],
              if (widget.ds.cancelledToday(widget.train))
                Card(
                  color: cs.errorContainer,
                  child: const ListTile(
                    leading: Icon(Icons.cancel),
                    title: Text('امروز طبق نامه‌ی ابلاغی این قطار حذف شده است'),
                  ),
                ),
              _statusCard(context, tl, a, st, cs),
              const SizedBox(height: 10),
              if (a.state != PosState.outside) _limits(context, a, cs),
              const SizedBox(height: 10),
              _delayCard(context, tl, a),
              const SizedBox(height: 10),
              if (a.state != PosState.outside) _recovery(context, a, st, tl),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('روشن ماندن صفحه'),
                value: keepAwake,
                onChanged: (v) {
                  setState(() => keepAwake = v);
                  _wake(v);
                },
              ),
              Text(
                'این اطلاعات فقط کمکی است و جایگزین علائم، دستورالعمل‌ها و محدودیت‌های رسمی راه‌آهن نیست. '
                'محدودیت‌های موقت سرعت در جدول نیست. محاسبه‌ها تقریبی و بدون احتساب شتاب و ترمز است.',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: cs.onSurfaceVariant),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _statusCard(
      BuildContext c, Timeline tl, Analysis a, List<Stop> st, ColorScheme cs) {
    final tt = Theme.of(c).textTheme;
    if (a.state == PosState.outside) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
              'اکنون خارج از بازه‌ی برنامه‌ی این قطار هستید (حرکت از مبدأ طبق برنامه ساعت ${st.first.departure}). '
              'اگر قطار در حال حرکت است، تأخیر یا روز سفر را تنظیم کنید.',
              style: tt.titleMedium),
        ),
      );
    }
    String top;
    switch (a.state) {
      case PosState.before:
        top = 'در مبدأ • حرکت تا ${fmtMinutes(a.dwellLeft)}';
        break;
      case PosState.dwell:
        top = 'توقف در ${st[a.current!].station} • حرکت تا ${fmtMinutes(a.dwellLeft)}';
        break;
      default:
        top = 'در حال حرکت';
    }
    final stNext = st[a.next];
    final noteNext = stNext.note;
    return Card(
      color: cs.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(top, style: tt.titleMedium),
          const SizedBox(height: 6),
          Text('ایستگاه بعد', style: tt.bodyMedium),
          Text(stNext.station,
              style: tt.headlineLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Center(
            child: Text(fmtMinutes(a.etaMin),
                style: tt.displayMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontFeatures: const [FontFeature.tabularFigures()])),
          ),
          Center(
              child: Text(
                  'تا رسیدن (برنامه: ${stNext.arrival ?? '-'}) • ${a.kmToNext.toStringAsFixed(1)} km مانده',
                  style: tt.bodyMedium)),
          if (noteNext != null) ...[
            const SizedBox(height: 8),
            Chip(
                avatar: const Icon(Icons.info_outline, size: 18),
                label: Text('ایستگاه بعد: $noteNext')),
          ],
        ]),
      ),
    );
  }

  Widget _limits(BuildContext c, Analysis a, ColorScheme cs) {
    Widget box(String label, int? v) => Expanded(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Column(children: [
                Text(label, style: Theme.of(c).textTheme.bodyMedium),
                Text(v == null ? '-' : '$v',
                    style: Theme.of(c)
                        .textTheme
                        .displaySmall
                        ?.copyWith(fontWeight: FontWeight.bold)),
                const Text('km/h'),
              ]),
            ),
          ),
        );
    return Row(children: [
      box('سرعت مجاز فعلی', a.limitNow),
      box('بعد از ایستگاه بعد', a.limitAfter),
    ]);
  }

  Widget _delayCard(BuildContext c, Timeline tl, Analysis a) {
    final tt = Theme.of(c).textTheme;
    final d = delay.round();
    final label = d == 0
        ? 'طبق برنامه'
        : d > 0
            ? '$d دقیقه تأخیر'
            : '${-d} دقیقه زودتر';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Text('وضعیت زمانی: $label',
              style: tt.titleLarge?.copyWith(
                  color: d > 0 ? Colors.orangeAccent : null,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton.filledTonal(
                onPressed: () => setState(() => delay -= 1),
                icon: const Icon(Icons.remove)),
            const SizedBox(width: 12),
            IconButton.filledTonal(
                onPressed: () => setState(() => delay += 1),
                icon: const Icon(Icons.add)),
            const SizedBox(width: 12),
            IconButton(
                tooltip: 'صفر کردن',
                onPressed: () => setState(() => delay = 0),
                icon: const Icon(Icons.restart_alt)),
          ]),
          const SizedBox(height: 4),
          OutlinedButton.icon(
            onPressed: () => _setActual(c, tl),
            icon: const Icon(Icons.schedule),
            label: const Text('ثبت ساعت واقعی ایستگاه'),
          ),
        ]),
      ),
    );
  }

  Future<void> _setActual(BuildContext c, Timeline tl) async {
    final st = tl.train.stops;
    final res = await showDialog<_ActualChoice>(
        context: c, builder: (_) => _ActualDialog(stops: st));
    if (res == null || !mounted) return;
    final s = st[res.index];
    final sched = clockToMin(res.useDeparture ? s.departure : s.arrival) ??
        clockToMin(s.departure ?? s.arrival);
    if (sched == null) return;
    final tod = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (ctx, child) => MediaQuery(
          data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
          child: child!),
    );
    if (tod == null || !mounted) return;
    final actual = tod.hour * 60 + tod.minute;
    // اختلاف را در بازه‌ی -۱۲ تا +۱۲ ساعت می‌گیریم
    final d = ((actual - sched + 720) % 1440) - 720;
    setState(() => delay = d.toDouble());
  }

  Widget _recovery(BuildContext c, Analysis a, List<Stop> st, Timeline tl) {
    final tt = Theme.of(c).textTheme;
    final late = delay.round() > 0;
    final rows = <Widget>[];

    String reqText(double? req, double recover) {
      if (req == null) return 'زمان برنامه‌ای گذشته است';
      return '${req.round()} km/h';
    }

    Widget line(String k, String v, {Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(children: [
            Expanded(child: Text(k)),
            Text(v,
                style: TextStyle(fontWeight: FontWeight.bold, color: color)),
          ]),
        );

    final lim = a.limitNow;
    final nextBad = a.reqToNext == null ||
        (lim != null && a.reqToNext! > lim + 0.5);
    rows.add(Text('تا ${st[a.next].station}', style: tt.titleMedium));
    rows.add(line('میانگین سرعت لازم برای رسیدن طبق برنامه',
        reqText(a.reqToNext, a.recoverNextMin),
        color: nextBad && late ? Colors.redAccent : null));
    if (late) {
      rows.add(line('حداکثر جبران ممکن در این قطعه',
          '${a.recoverNextMin.toStringAsFixed(1)} دقیقه'));
    }
    rows.add(const Divider());
    rows.add(Text('تا مقصد (${st.last.station})', style: tt.titleMedium));
    rows.add(line('میانگین سرعت طبق برنامه (بدون توقف)',
        a.schedAvgToEnd == null ? '-' : '${a.schedAvgToEnd!.round()} km/h'));
    final endBad = a.reqToEnd == null;
    rows.add(line('میانگین لازم برای رسیدن طبق برنامه',
        reqText(a.reqToEnd, a.recoverEndMin),
        color: endBad && late ? Colors.redAccent : null));
    rows.add(line('مسافت باقی‌مانده', '${a.kmToEnd.toStringAsFixed(0)} km'));
    if (late) {
      final ok = delay <= a.recoverEndMin;
      rows.add(line(
          'حداکثر جبران ممکن تا مقصد',
          '${a.recoverEndMin.toStringAsFixed(0)} دقیقه'
              '${ok ? '' : '  (کمتر از تأخیر!)'}',
          color: ok ? null : Colors.redAccent));
      if (!a.limitsKnown) {
        rows.add(const Text('برای بعضی قطعه‌ها سرعت مجاز نامعلوم بود.'));
      }
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: rows),
      ),
    );
  }
}

class _ActualChoice {
  final int index;
  final bool useDeparture;
  _ActualChoice(this.index, this.useDeparture);
}

class _ActualDialog extends StatefulWidget {
  final List<Stop> stops;
  const _ActualDialog({required this.stops});
  @override
  State<_ActualDialog> createState() => _ActualDialogState();
}

class _ActualDialogState extends State<_ActualDialog> {
  int idx = 0;
  bool dep = true;

  @override
  Widget build(BuildContext context) {
    final s = widget.stops[idx];
    final canBoth = s.arrival != null && s.departure != null;
    return AlertDialog(
      title: const Text('ثبت ساعت واقعی'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButton<int>(
          isExpanded: true,
          value: idx,
          items: [
            for (var i = 0; i < widget.stops.length; i++)
              DropdownMenuItem(value: i, child: Text(widget.stops[i].station)),
          ],
          onChanged: (v) => setState(() => idx = v ?? 0),
        ),
        const SizedBox(height: 8),
        if (canBoth)
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('ورود')),
              ButtonSegment(value: true, label: Text('حرکت')),
            ],
            selected: {dep},
            onSelectionChanged: (v) => setState(() => dep = v.first),
          )
        else
          Text(s.departure != null
              ? 'ساعت حرکت طبق برنامه: ${s.departure}'
              : 'ساعت ورود طبق برنامه: ${s.arrival}'),
        if (canBoth)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
                'طبق برنامه: ${dep ? s.departure : s.arrival}'),
          ),
      ]),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('انصراف')),
        FilledButton(
            onPressed: () => Navigator.pop(
                context,
                _ActualChoice(idx, canBoth ? dep : s.departure != null)),
            child: const Text('ادامه')),
      ],
    );
  }
}

// ------------------------------------------------------------ جدول مسیر

class RouteTable extends StatelessWidget {
  final Train train;
  const RouteTable({super.key, required this.train});

  static const _w = [150.0, 56.0, 56.0, 44.0, 66.0, 62.0, 52.0, 48.0, 76.0];
  static const _h = [
    'ایستگاه',
    'ورود',
    'حرکت',
    'توقف',
    'km رسمی',
    'km واقعی',
    'تا بعدی',
    'دقیقه',
    'سرعت'
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final stops = train.stops;
    final width = _w.fold<double>(0, (a, b) => a + b);

    Widget cell(int i, Widget child, {Alignment al = Alignment.center}) =>
        SizedBox(
            width: _w[i],
            child: Align(alignment: al, child: child));

    Widget header() => Container(
          color: cs.surfaceContainerHighest,
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(children: [
            for (var i = 0; i < _h.length; i++)
              cell(
                  i,
                  Text(_h[i],
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  al: i == 0 ? Alignment.centerRight : Alignment.center),
          ]),
        );

    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(8),
        child: Text(
            '${train.from} ← ${train.to}  •  ${train.days}\n'
            'km رسمی همان کیلومتراژ خط است؛ km واقعی فاصله‌ی طی‌شده از مبدأ این قطار است.',
            style: Theme.of(context).textTheme.bodySmall),
      ),
      Expanded(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: width,
            child: Column(children: [
              header(),
              Expanded(
                child: ListView.builder(
                  itemCount: stops.length,
                  itemBuilder: (_, k) {
                    final s = stops[k];
                    final prevLim = k > 0 ? stops[k - 1].limitSpeed : null;
                    final lim = s.limitSpeed;
                    IconData? arrow;
                    Color? arrowColor;
                    if (prevLim != null && lim != null && lim != prevLim) {
                      arrow = lim > prevLim
                          ? Icons.arrow_upward
                          : Icons.arrow_downward;
                      arrowColor = lim > prevLim
                          ? Colors.green
                          : Colors.redAccent;
                    }
                    final speedTxt = s.segMinutes == null
                        ? ''
                        : (s.speedRaw ?? '${s.maxSpeed ?? '-'}');
                    return Container(
                      color: k.isEven ? null : cs.surfaceContainerLow,
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(children: [
                        cell(
                            0,
                            Padding(
                              padding: const EdgeInsets.only(right: 6),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(s.station,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600)),
                                    if (s.note != null)
                                      Text(s.note!,
                                          style: TextStyle(
                                              fontSize: 11,
                                              color: cs.tertiary)),
                                  ]),
                            ),
                            al: Alignment.centerRight),
                        cell(1, Text(s.arrival ?? '-')),
                        cell(2, Text(s.departure ?? '-')),
                        cell(3, Text(s.stopMin == null || s.stopMin == 0
                            ? ''
                            : '${s.stopMin}')),
                        cell(4, Text(s.kmOfficial == null ? '-' : '${s.kmOfficial}')),
                        cell(5, Text('${s.km}')),
                        cell(6, Text(s.segKm == null ? '' : '${s.segKm}')),
                        cell(7, Text(s.segMinutes == null ? '' : '${s.segMinutes}')),
                        cell(
                            8,
                            Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  if (arrow != null)
                                    Icon(arrow, size: 14, color: arrowColor),
                                  if (s.speedRaw != null)
                                    const Icon(Icons.warning_amber,
                                        size: 14, color: Colors.orange),
                                  Text(speedTxt,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: arrowColor)),
                                ])),
                      ]),
                    );
                  },
                ),
              ),
            ]),
          ),
        ),
      ),
    ]);
  }
}
