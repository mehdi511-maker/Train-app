import 'dart:convert';

/// یکسان‌سازی متن فارسی برای جستجو (ی/ک عربی، نیم‌فاصله، ارقام).
String norm(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final i1 = ar.indexOf(c), i2 = fa.indexOf(c);
    if (i1 >= 0) {
      b.write(i1);
    } else if (i2 >= 0) {
      b.write(i2);
    } else if (c == 'ي') {
      b.write('ی');
    } else if (c == 'ك') {
      b.write('ک');
    } else if (c == '\u200c') {
      b.write(' ');
    } else {
      b.write(c);
    }
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// امروز به شمسی، به‌صورت عدد ۸ رقمی مثل 14050801
int todayJalali([DateTime? now]) {
  final d = now ?? DateTime.now();
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = d.month > 2 ? d.year + 1 : d.year;
  var days = 355666 +
      365 * d.year +
      ((gy2 + 3) ~/ 4) -
      ((gy2 + 99) ~/ 100) +
      ((gy2 + 399) ~/ 400) +
      d.day +
      gdm[d.month - 1];
  var jy = -1595 + 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  int jm, jd;
  if (days < 186) {
    jm = 1 + days ~/ 31;
    jd = 1 + days % 31;
  } else {
    jm = 7 + (days - 186) ~/ 30;
    jd = 1 + (days - 186) % 30;
  }
  return jy * 10000 + jm * 100 + jd;
}

int dateToInt(String s) => int.tryParse(s.replaceAll('/', '')) ?? 0;

String fmtDate(int d) {
  final s = d.toString().padLeft(8, '0');
  return '${s.substring(0, 4)}/${s.substring(4, 6)}/${s.substring(6)}';
}

class Stop {
  final String station;
  final String? note, arrival, departure;
  final int? stopMin, segMinutes;
  final int km;
  Stop.fromJson(Map<String, dynamic> j)
      : station = j['station'] as String,
        note = j['note'] as String?,
        arrival = j['arrival'] as String?,
        departure = j['departure'] as String?,
        stopMin = j['stop_min'] as int?,
        km = (j['km'] as num?)?.toInt() ?? 0,
        segMinutes = (j['segment_to_next'] as Map?)?['minutes'] as int?;
}

class Train {
  final String number, days, from, to, title;
  final int validFrom, validTo;
  final List<Stop> stops;
  late final List<String> normNames = stops.map((s) => norm(s.station)).toList();
  Train(this.number, this.days, this.from, this.to, this.title, this.validFrom,
      this.validTo, this.stops);
}

class Dataset {
  final List<Train> trains;
  final int validTo; // آخرین تاریخ انقضا
  final int validFrom;
  Dataset(this.trains, this.validFrom, this.validTo);

  bool isExpired([int? today]) => (today ?? todayJalali()) > validTo;

  List<String> get stations {
    final set = <String>{};
    for (final t in trains) {
      for (final s in t.stops) {
        set.add(s.station);
      }
    }
    return set.toList()..sort();
  }

  static Dataset parse(String raw) {
    final j = jsonDecode(raw);
    if (j is! Map || j['timetables'] is! List) {
      throw const FormatException('ساختار فایل نامعتبر است');
    }
    final trains = <Train>[];
    var vf = 99999999, vt = 0;
    for (final tt in j['timetables'] as List) {
      final from = dateToInt(tt['valid_from'] as String);
      final to = dateToInt(tt['valid_to'] as String);
      if (from < vf) vf = from;
      if (to > vt) vt = to;
      for (final tr in tt['trains'] as List) {
        trains.add(Train(
          tr['number'].toString(),
          (tr['days'] ?? '') as String,
          tr['from'] as String,
          tr['to'] as String,
          (tt['title'] ?? '') as String,
          from,
          to,
          [for (final s in tr['stops'] as List) Stop.fromJson(s)],
        ));
      }
    }
    if (trains.isEmpty) throw const FormatException('هیچ قطاری در فایل نیست');
    return Dataset(trains, vf, vt);
  }
}

class TripMatch {
  final Train train;
  final int i, j; // اندیس ایستگاه مبدأ و مقصد (j=-1 یعنی مقصد نهایی قطار)
  TripMatch(this.train, this.i, this.j);

  Stop get origin => train.stops[i];
  Stop get dest => train.stops[j < 0 ? train.stops.length - 1 : j];

  String get departTime => origin.departure ?? origin.arrival ?? '';
  String get arriveTime => dest.arrival ?? dest.departure ?? '';

  int? get durationMin {
    final jj = j < 0 ? train.stops.length - 1 : j;
    var total = 0;
    for (var k = i; k < jj; k++) {
      final seg = train.stops[k].segMinutes;
      if (seg == null) return null;
      total += seg;
      final st = train.stops[k + 1].stopMin;
      if (k + 1 < jj && st != null) total += st;
    }
    return total;
  }
}

int _find(Train t, String q, int from) {
  for (var k = from; k < t.normNames.length; k++) {
    if (t.normNames[k] == q) return k;
  }
  for (var k = from; k < t.normNames.length; k++) {
    if (t.normNames[k].contains(q)) return k;
  }
  return -1;
}

/// جستجو: مبدأ و/یا مقصد (نام ایستگاه) یا شماره قطار.
List<TripMatch> search(Dataset ds, String q1, String q2) {
  final a = norm(q1), b = norm(q2);
  if (a.isEmpty && b.isEmpty) return [];
  final out = <TripMatch>[];
  if (b.isEmpty && RegExp(r"^\d+$").hasMatch(a)) {
    for (final t in ds.trains) {
      if (t.number.startsWith(a)) out.add(TripMatch(t, 0, -1));
    }
    return out;
  }
  for (final t in ds.trains) {
    final i = a.isEmpty ? 0 : _find(t, a, 0);
    if (i < 0) continue;
    if (b.isEmpty) {
      if (i < t.stops.length - 1) out.add(TripMatch(t, i, -1));
      continue;
    }
    final j = _find(t, b, i + 1);
    if (j > i) out.add(TripMatch(t, i, j));
  }
  out.sort((x, y) => x.departTime.compareTo(y.departTime));
  return out;
}
