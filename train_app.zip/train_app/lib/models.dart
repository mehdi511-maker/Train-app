import 'dart:convert';

/// یکسان‌سازی متن فارسی برای جستجو (ی/ک عربی، نیم‌فاصله، ارقام).
String norm(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final i1 = ar.indexOf(c), i2 = fa.indexOf(c);
    if (i1 >= 0) {
      b.write(i1);
    } else if (i2 >= 0) {
      b.write(i2);
    } else if (c == 'ي') {
      b.write('ی');
    } else if (c == 'ك') {
      b.write('ک');
    } else if (c == '\u200c') {
      b.write(' ');
    } else {
      b.write(c);
    }
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// امروز به شمسی، به‌صورت عدد ۸ رقمی مثل 14050801
int todayJalali([DateTime? now]) {
  final d = now ?? DateTime.now();
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = d.month > 2 ? d.year + 1 : d.year;
  var days = 355666 +
      365 * d.year +
      ((gy2 + 3) ~/ 4) -
      ((gy2 + 99) ~/ 100) +
      ((gy2 + 399) ~/ 400) +
      d.day +
      gdm[d.month - 1];
  var jy = -1595 + 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  int jm, jd;
  if (days < 186) {
    jm = 1 + days ~/ 31;
    jd = 1 + days % 31;
  } else {
    jm = 7 + (days - 186) ~/ 30;
    jd = 1 + (days - 186) % 30;
  }
  return jy * 10000 + jm * 100 + jd;
}

int dateToInt(String s) => int.tryParse(s.replaceAll('/', '')) ?? 0;

String fmtDate(int d) {
  final s = d.toString().padLeft(8, '0');
  return '${s.substring(0, 4)}/${s.substring(4, 6)}/${s.substring(6)}';
}

class Stop {
  final String station;
  final String? note, arrival, departure, speedRaw;
  final int? stopMin, segMinutes, segKm, maxSpeed, kmOfficial;
  final int km; // فاصله‌ی واقعی از مبدأ قطار
  Stop.fromJson(Map<String, dynamic> j)
      : station = j['station'] as String,
        note = j['note'] as String?,
        arrival = j['arrival'] as String?,
        departure = j['departure'] as String?,
        stopMin = j['stop_min'] as int?,
        km = (j['km'] as num?)?.toInt() ?? 0,
        kmOfficial = (j['km_official'] as num?)?.toInt(),
        segMinutes = (j['segment_to_next'] as Map?)?['minutes'] as int?,
        segKm = ((j['segment_to_next'] as Map?)?['km'] as num?)?.toInt(),
        maxSpeed = ((j['segment_to_next'] as Map?)?['max_speed'] as num?)?.toInt(),
        speedRaw = (j['segment_to_next'] as Map?)?['max_speed_raw'] as String?;

  /// سرعت مجاز قطعه‌ی بعدی. اگر دو مقدار (مثل 100/80) ثبت شده باشد، مقدار کمتر.
  int? get limitSpeed {
    final r = speedRaw;
    if (r != null) {
      final nums = RegExp(r'\d+')
          .allMatches(r)
          .map((m) => int.parse(m.group(0)!))
          .toList();
      if (nums.isNotEmpty) return nums.reduce((a, b) => a < b ? a : b);
    }
    return maxSpeed;
  }
}

class Train {
  final String number, days, from, to, title;
  final int validFrom, validTo;
  final List<Stop> stops;
  late final List<String> normNames = stops.map((s) => norm(s.station)).toList();
  Train(this.number, this.days, this.from, this.to, this.title, this.validFrom,
      this.validTo, this.stops);
}

class OpEntry {
  final String region, mode;
  final String? section;
  OpEntry.fromJson(Map<String, dynamic> j)
      : region = j['region'] as String,
        mode = j['mode'] as String,
        section = j['section'] as String?;
}

/// یک بند از نامه‌ی «اعمال تغییرات برنامه قطارهای مسافری».
class ChangeItem {
  final int no;
  final String train, kind, direction, text;
  final String? route, operator, oldTime, newTime;
  final List<String> also;
  final List<int> dates; // تاریخ‌های شمسی به‌صورت عدد ۸ رقمی، مرتب‌شده
  ChangeItem.fromJson(Map<String, dynamic> j)
      : no = (j['no'] as num).toInt(),
        train = (j['train'] ?? '').toString(),
        kind = (j['kind'] ?? 'other') as String,
        direction = (j['direction'] ?? 'both') as String,
        text = (j['text'] ?? '') as String,
        route = j['route'] as String?,
        operator = j['operator'] as String?,
        oldTime = j['old_time'] as String?,
        newTime = j['new_time'] as String?,
        also = [for (final a in (j['also'] as List? ?? const [])) a.toString()],
        dates = [
          for (final d in (j['dates'] as List? ?? const [])) dateToInt(d.toString())
        ]..sort();
}

class Dataset {
  final List<Train> trains;
  final int validTo; // آخرین تاریخ انقضا
  final int validFrom;
  final int dataVersion; // با هر ویرایش داده (حتی بدون تغییر تاریخ انقضا) بالا می‌رود
  final List<ChangeItem> changes;
  final String changesTitle;
  final Map<String, List<OpEntry>> operations;
  final String opsTitle, opsNote;
  final int opsValidTo;
  final Map<String, String> partner; // شماره قطار -> شماره قطار برگشت/رفت
  Dataset(this.trains, this.validFrom, this.validTo,
      {this.dataVersion = 0,
      this.changes = const [],
      this.changesTitle = '',
      this.operations = const {},
      this.opsTitle = '',
      this.opsNote = '',
      this.opsValidTo = 0,
      this.partner = const {}});

  bool isExpired([int? today]) => (today ?? todayJalali()) > validTo;

  /// آیا این داده از [other] جدیدتر است؟
  bool isNewerThan(Dataset other) =>
      validTo > other.validTo ||
      (validTo == other.validTo && dataVersion > other.dataVersion);

  List<String> get stations {
    final set = <String>{};
    for (final t in trains) {
      for (final s in t.stops) {
        set.add(s.station);
      }
    }
    return set.toList()..sort();
  }

  List<OpEntry> opsFor(Train t) => operations[t.number] ?? const [];

  /// تغییرات نامه برای این قطار که هنوز تمام نشده‌اند.
  List<ChangeItem> changesFor(Train t, [int? today]) {
    final now = today ?? todayJalali();
    final out = <ChangeItem>[];
    for (final c in changes) {
      final names = [c.train, ...c.also];
      final direct = names.contains(t.number);
      final viaPair = c.kind == 'cancel' &&
          c.direction == 'both' &&
          names.any((n) => partner[n] == t.number);
      if (!direct && !viaPair) continue;
      if (c.dates.isNotEmpty && c.dates.last < now) continue;
      out.add(c);
    }
    return out;
  }

  bool cancelledToday(Train t, [int? today]) {
    final now = today ?? todayJalali();
    return changesFor(t, now)
        .any((c) => c.kind == 'cancel' && c.dates.contains(now));
  }

  static Dataset parse(String raw) {
    final j = jsonDecode(raw);
    if (j is! Map || j['timetables'] is! List) {
      throw const FormatException('ساختار فایل نامعتبر است');
    }
    final trains = <Train>[];
    final partner = <String, String>{};
    var vf = 99999999, vt = 0;
    for (final tt in j['timetables'] as List) {
      final from = dateToInt(tt['valid_from'] as String);
      final to = dateToInt(tt['valid_to'] as String);
      if (from < vf) vf = from;
      if (to > vt) vt = to;
      final trs = tt['trains'] as List;
      if (trs.length == 2) {
        final a = trs[0]['number'].toString(), b = trs[1]['number'].toString();
        partner[a] = b;
        partner[b] = a;
      }
      for (final tr in trs) {
        trains.add(Train(
          tr['number'].toString(),
          (tr['days'] ?? '') as String,
          tr['from'] as String,
          tr['to'] as String,
          (tt['title'] ?? '') as String,
          from,
          to,
          [for (final s in tr['stops'] as List) Stop.fromJson(s)],
        ));
      }
    }
    if (trains.isEmpty) throw const FormatException('هیچ قطاری در فایل نیست');

    // بخش‌های اختیاری؛ اگر خراب بودند نادیده گرفته می‌شوند.
    final changes = <ChangeItem>[];
    var changesTitle = '';
    final ch = j['changes'];
    if (ch is Map && ch['items'] is List) {
      changesTitle = (ch['title'] ?? '').toString();
      for (final it in ch['items'] as List) {
        try {
          changes.add(ChangeItem.fromJson(Map<String, dynamic>.from(it as Map)));
        } catch (_) {}
      }
    }
    final ops = <String, List<OpEntry>>{};
    final opsRaw = j['operations'];
    if (opsRaw is Map) {
      opsRaw.forEach((k, v) {
        try {
          ops[k.toString()] = [
            for (final e in v as List)
              OpEntry.fromJson(Map<String, dynamic>.from(e as Map))
          ];
        } catch (_) {}
      });
    }
    final meta = j['operations_meta'];
    return Dataset(
      trains,
      vf,
      vt,
      dataVersion: (j['data_version'] as num?)?.toInt() ?? 0,
      changes: changes,
      changesTitle: changesTitle,
      operations: ops,
      opsTitle: meta is Map ? (meta['title'] ?? '').toString() : '',
      opsNote: meta is Map ? (meta['note'] ?? '').toString() : '',
      opsValidTo: meta is Map ? dateToInt((meta['valid_to'] ?? '').toString()) : 0,
      partner: partner,
    );
  }
}

class TripMatch {
  final Train train;
  final int i, j; // اندیس ایستگاه مبدأ و مقصد (j=-1 یعنی مقصد نهایی قطار)
  TripMatch(this.train, this.i, this.j);

  Stop get origin => train.stops[i];
  Stop get dest => train.stops[j < 0 ? train.stops.length - 1 : j];

  String get departTime => origin.departure ?? origin.arrival ?? '';
  String get arriveTime => dest.arrival ?? dest.departure ?? '';

  int? get durationMin {
    final jj = j < 0 ? train.stops.length - 1 : j;
    var total = 0;
    for (var k = i; k < jj; k++) {
      final seg = train.stops[k].segMinutes;
      if (seg == null) return null;
      total += seg;
      final st = train.stops[k + 1].stopMin;
      if (k + 1 < jj && st != null) total += st;
    }
    return total;
  }
}

int _find(Train t, String q, int from) {
  for (var k = from; k < t.normNames.length; k++) {
    if (t.normNames[k] == q) return k;
  }
  for (var k = from; k < t.normNames.length; k++) {
    if (t.normNames[k].contains(q)) return k;
  }
  return -1;
}

/// جستجو: مبدأ و/یا مقصد (نام ایستگاه) یا شماره قطار.
List<TripMatch> search(Dataset ds, String q1, String q2) {
  final a = norm(q1), b = norm(q2);
  if (a.isEmpty && b.isEmpty) return [];
  final out = <TripMatch>[];
  if (b.isEmpty && RegExp(r"^\d+$").hasMatch(a)) {
    for (final t in ds.trains) {
      if (t.number.startsWith(a)) out.add(TripMatch(t, 0, -1));
    }
    return out;
  }
  for (final t in ds.trains) {
    final i = a.isEmpty ? 0 : _find(t, a, 0);
    if (i < 0) continue;
    if (b.isEmpty) {
      if (i < t.stops.length - 1) out.add(TripMatch(t, i, -1));
      continue;
    }
    final j = _find(t, b, i + 1);
    if (j > i) out.add(TripMatch(t, i, j));
  }
  out.sort((x, y) => x.departTime.compareTo(y.departTime));
  return out;
}
