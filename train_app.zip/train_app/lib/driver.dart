import 'models.dart';

int? clockToMin(String? t) {
  if (t == null) return null;
  final p = t.split(':');
  if (p.length != 2) return null;
  final h = int.tryParse(p[0]), m = int.tryParse(p[1]);
  if (h == null || m == null) return null;
  return h * 60 + m;
}

/// جدول زمانی یک قطار بر حسب دقیقه از لحظه‌ی حرکت از مبدأ (با در نظر گرفتن گذر از نیمه‌شب).
class Timeline {
  final Train train;
  final int t0; // ساعت حرکت از مبدأ (دقیقه از ۰۰:۰۰)
  final List<double> arr; // زمان ورود به هر ایستگاه
  final List<double> dep; // زمان حرکت از هر ایستگاه
  Timeline._(this.train, this.t0, this.arr, this.dep);

  double get total => arr.last;
  int get n => train.stops.length;

  static Timeline? build(Train t) {
    final s = t.stops;
    if (s.length < 2) return null;
    final t0 = clockToMin(s.first.departure);
    if (t0 == null) return null;
    final arr = List<double>.filled(s.length, 0);
    final dep = List<double>.filled(s.length, 0);
    var prev = t0; // زمان مطلق (ساعت) آخرین رویداد
    int unwrap(int c) {
      var cand = (prev ~/ 1440) * 1440 + c;
      while (cand < prev) {
        cand += 1440;
      }
      prev = cand;
      return cand - t0;
    }

    for (var i = 1; i < s.length; i++) {
      final a = clockToMin(s[i].arrival);
      final d = clockToMin(s[i].departure);
      if (a == null) {
        // ورود ثبت نشده: از زمان قطعه‌ی قبلی تخمین می‌زنیم
        final est = dep[i - 1] + (s[i - 1].segMinutes ?? 0);
        arr[i] = est;
        prev = t0 + est.round();
      } else {
        arr[i] = unwrap(a).toDouble();
      }
      dep[i] = d == null ? arr[i] : unwrap(d).toDouble();
    }
    return Timeline._(t, t0, arr, dep);
  }
}

enum PosState { before, dwell, moving, outside }

class Analysis {
  final PosState state;
  final int next; // اندیس ایستگاه بعدی
  final int? current; // ایستگاهی که در آن توقف دارد (در حالت dwell/before)
  final double etaMin; // دقیقه تا رسیدن به ایستگاه بعد (با احتساب تأخیر)
  final double dwellLeft; // دقیقه تا حرکت (توقف باقی‌مانده)
  final double kmToNext;
  final double? reqToNext; // میانگین سرعت لازم برای رسیدن طبق برنامه
  final double recoverNextMin; // حداکثر جبران ممکن تا ایستگاه بعد
  final int? limitNow, limitAfter;
  final double kmToEnd;
  final double? reqToEnd, schedAvgToEnd;
  final double recoverEndMin;
  final bool limitsKnown; // آیا برای همه‌ی قطعه‌ها سرعت مجاز معلوم بود
  Analysis({
    required this.state,
    this.next = 0,
    this.current,
    this.etaMin = 0,
    this.dwellLeft = 0,
    this.kmToNext = 0,
    this.reqToNext,
    this.recoverNextMin = 0,
    this.limitNow,
    this.limitAfter,
    this.kmToEnd = 0,
    this.reqToEnd,
    this.schedAvgToEnd,
    this.recoverEndMin = 0,
    this.limitsKnown = true,
  });
}

/// [delta]: موقعیت فعلی روی جدول برنامه (دقیقه از حرکت مبدأ، طبق ساعت گوشی)
/// [delay]: تأخیر بر حسب دقیقه (منفی یعنی زودتر)
Analysis analyze(Timeline tl, double delta, double delay) {
  final st = tl.train.stops;
  final n = tl.n;
  final x = delta - delay; // موقعیت واقعی قطار روی جدول
  if (x >= tl.total) return Analysis(state: PosState.outside);

  var state = PosState.before;
  var s = 0; // قطعه‌ای که در حال طی شدن است (اندیس ایستگاه مبدأ آن)
  var f = 0.0; // کسر طی‌شده از قطعه‌ی s
  double dwellLeft = 0;
  if (x < 0) {
    state = PosState.before;
    dwellLeft = -x;
  } else {
    var found = false;
    for (var k = 0; k < n && !found; k++) {
      if (k > 0 && k < n - 1 && x >= tl.arr[k] && x < tl.dep[k]) {
        state = PosState.dwell;
        s = k;
        dwellLeft = tl.dep[k] - x;
        found = true;
      } else if (k < n - 1 && x >= tl.dep[k] && x < tl.arr[k + 1]) {
        state = PosState.moving;
        s = k;
        final len = tl.arr[k + 1] - tl.dep[k];
        f = len <= 0 ? 0 : (x - tl.dep[k]) / len;
        found = true;
      }
    }
    if (!found) return Analysis(state: PosState.outside);
  }

  double segKm(int i) => (st[i].segKm ?? 0).toDouble();
  double segSched(int i) => tl.arr[i + 1] - tl.dep[i];

  final remKmFirst = segKm(s) * (1 - f);
  final remSchedFirst = segSched(s) * (1 - f);
  final next = s + 1;

  // --- تا ایستگاه بعد ---
  final availNext = tl.arr[next] - delta; // وقت باقی‌مانده تا ساعت برنامه‌ای رسیدن
  final runAvailNext = availNext - dwellLeft;
  double? reqNext = runAvailNext > 0.5 ? remKmFirst / (runAvailNext / 60) : null;

  var limitsKnown = true;
  final lim0 = st[s].limitSpeed;
  double minRunFirst = remSchedFirst;
  if (lim0 != null && lim0 > 0) {
    minRunFirst = remKmFirst / lim0 * 60;
  } else {
    limitsKnown = false;
  }
  var recoverNext = remSchedFirst - minRunFirst;
  if (recoverNext < 0) recoverNext = 0;

  // --- تا مقصد ---
  var kmEnd = remKmFirst;
  var schedRun = remSchedFirst;
  var minRun = minRunFirst;
  var dwellInter = 0.0;
  for (var m = s + 1; m < n - 1; m++) {
    kmEnd += segKm(m);
    schedRun += segSched(m);
    final lim = st[m].limitSpeed;
    if (lim != null && lim > 0) {
      minRun += segKm(m) / lim * 60;
    } else {
      minRun += segSched(m);
      limitsKnown = false;
    }
    dwellInter += tl.dep[m] - tl.arr[m];
  }
  final runAvailEnd = (tl.total - delta) - dwellLeft - dwellInter;
  final reqEnd = runAvailEnd > 0.5 ? kmEnd / (runAvailEnd / 60) : null;
  final schedAvg = schedRun > 0 ? kmEnd / (schedRun / 60) : null;
  var recoverEnd = schedRun - minRun;
  if (recoverEnd < 0) recoverEnd = 0;

  return Analysis(
    state: state,
    next: next,
    current: state == PosState.moving ? null : s,
    etaMin: dwellLeft + remSchedFirst,
    dwellLeft: dwellLeft,
    kmToNext: remKmFirst,
    reqToNext: reqNext,
    recoverNextMin: recoverNext,
    limitNow: lim0,
    limitAfter: next < n - 1 ? st[next].limitSpeed : null,
    kmToEnd: kmEnd,
    reqToEnd: reqEnd,
    schedAvgToEnd: schedAvg,
    recoverEndMin: recoverEnd,
    limitsKnown: limitsKnown,
  );
}

/// موقعیت فعلی روی جدول برنامه از روی ساعت گوشی.
/// [dayOffset]: برای قطارهای بیش از ۲۴ ساعت، روز چندم سفر (۰ = روز اول).
double scheduleDelta(Timeline tl, DateTime now, int dayOffset) {
  final nowMin = now.hour * 60 + now.minute + now.second / 60.0;
  var d = (nowMin - tl.t0) % 1440;
  if (d < 0) d += 1440;
  return d + dayOffset * 1440;
}

String fmtMinutes(double m) {
  final neg = m < 0;
  var sec = (m.abs() * 60).round();
  final h = sec ~/ 3600;
  sec %= 3600;
  final mm = sec ~/ 60, ss = sec % 60;
  final t = h > 0
      ? '$h:${mm.toString().padLeft(2, '0')}:${ss.toString().padLeft(2, '0')}'
      : '${mm.toString().padLeft(2, '0')}:${ss.toString().padLeft(2, '0')}';
  return neg ? '-$t' : t;
}
