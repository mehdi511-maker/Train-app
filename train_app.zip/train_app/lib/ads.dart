import 'package:flutter/services.dart';

/// شناسه اپلیکیشن از پنل تپسل
const kTapsellAppKey =
    'idmebrhsdqqfmfldfejttnanopepqpoblmobophgtseqcmpntarsckbmqkbkncdfnjstit';

/// شناسه جایگاه تبلیغ ویدئویی بین‌صفحه‌ای (Interstitial Video)
const kInterstitialZoneId = '6ae4e2c77ae48b79af14cf45';

/// تبلیغ فقط در بیلدی فعال است که workflow با گزینه ads اجرا شود.
const kAdsBuild = bool.fromEnvironment('ADS', defaultValue: false);

bool get adsEnabled =>
    kAdsBuild && kTapsellAppKey.isNotEmpty && kInterstitialZoneId.isNotEmpty;

/// در این نسخه تبلیغ بنری غیرفعال است؛ برای سازگاری با فاصله‌گذاری صفحات صفر است.
double get adsBottomPad => 0;

const _channel = MethodChannel('railpeyma/ads');

/// پل تبلیغ ویدئویی بین‌صفحه‌ای تپسل از طریق SDK بومی اندروید.
class Ads {
  static bool _ready = false;
  static Future<void>? _initializing;

  static Future<void> init() {
    if (!adsEnabled) return Future<void>.value();
    return _initializing ??= _initOnce();
  }

  static Future<void> _initOnce() async {
    try {
      _ready = (await _channel.invokeMethod<bool>(
            'init',
            {'key': kTapsellAppKey},
          )) ??
          false;
    } catch (_) {
      _ready = false;
    }
  }

  /// اگر تبلیغ آماده نشد یا خطا داد، false برمی‌گرداند تا اپ مستقیم ادامه دهد.
  /// در صورت نمایش، پس از بسته‌شدن تبلیغ true برمی‌گرداند.
  static Future<bool> showInterstitial() async {
    if (!adsEnabled) return false;
    if (!_ready) await init();
    if (!_ready) return false;

    try {
      return await _channel
              .invokeMethod<bool>(
                'showInterstitial',
                {'zone': kInterstitialZoneId},
              )
              .timeout(const Duration(seconds: 25)) ??
          false;
    } catch (_) {
      return false;
    }
  }
}
