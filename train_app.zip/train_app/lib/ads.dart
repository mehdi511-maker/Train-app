import 'package:tapsell_plus/tapsell_plus.dart';

/// کلید برنامه و شناسه‌ی زون بنر از پنل تپسل.
/// (این مقدارها محرمانه نیستند؛ تبلیغ‌دهنده‌ها هم داخل اپ می‌بینندشان.)
/// برای خاموش کردن تبلیغ، یکی از دو مقدار را خالی بگذارید.
const kTapsellAppKey =
    'idmebrhsdqqfmfldfejttnanopepqpoblmobophgtseqcmpntarsckbmqkbkncdfnjstit';
const kBannerZoneId = '6ae4e2c77ae48b79af14cf45';

bool get adsEnabled => kTapsellAppKey.isNotEmpty && kBannerZoneId.isNotEmpty;

/// ارتفاع بنر ۳۲۰×۵۰ (برای فاصله‌ی پایین صفحه‌ها تا چیزی زیر بنر نماند)
const kBannerHeight = 56.0;
double get adsBottomPad => adsEnabled ? kBannerHeight : 0;

/// بنر تپسل یک نمای بومی روی کل اپ است؛ پس در صفحه‌های لکوموتیورانی پنهانش می‌کنیم.
class Ads {
  static bool _ready = false;
  static bool _requesting = false;
  static bool _visible = false;
  static String? _id;

  static Future<void> init() async {
    if (!adsEnabled) return;
    try {
      _ready = await TapsellPlus.instance.initialize(kTapsellAppKey);
    } catch (_) {
      _ready = false;
    }
  }

  static Future<void> showBanner() async {
    _visible = true;
    if (!_ready) return;
    try {
      if (_id != null) {
        await TapsellPlus.instance.displayStandardBanner();
        return;
      }
      if (_requesting) return;
      _requesting = true;
      await TapsellPlus.instance.requestStandardBannerAd(
        kBannerZoneId,
        TapsellPlusBannerType.BANNER_320x50,
        onResponse: (map) async {
          _requesting = false;
          final id = map['response_id'];
          if (id == null) return;
          _id = id;
          try {
            await TapsellPlus.instance.showStandardBannerAd(
              id,
              TapsellPlusHorizontalGravity.BOTTOM,
              TapsellPlusVerticalGravity.CENTER,
              onOpened: (_) {},
              onError: (_) {},
            );
            // اگر در فاصله‌ی دریافت تبلیغ کاربر وارد صفحه‌ی بدون تبلیغ شده بود
            if (!_visible) await TapsellPlus.instance.hideStandardBanner();
          } catch (_) {}
        },
        onError: (map) {
          _requesting = false;
        },
      );
    } catch (_) {
      _requesting = false;
    }
  }

  static Future<void> hideBanner() async {
    _visible = false;
    if (_id == null) return;
    try {
      await TapsellPlus.instance.hideStandardBanner();
    } catch (_) {}
  }
}
