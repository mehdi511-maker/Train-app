import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'access.dart';
import 'ads.dart';
import 'pro_purchase.dart';
import 'help_page.dart';

/// فونت‌های همراه اپ (assets/fonts) و فونت‌های سیستمی اندروید.
/// وجود فونت‌های سیستمی به گوشی بستگی دارد؛ اگر نبود، فونت پیش‌فرض نمایش داده می‌شود.
const kFonts = <String, String?>{
  'پیش‌فرض': null,
  'هما': 'BHoma',
  'کامران': 'BKamran',
  'تیر': 'BTir',
  'کودک': 'BKoodak',
  'تیتر': 'BTitr',
  'Sans-serif': 'sans-serif',
  'Serif': 'serif',
  'Monospace': 'monospace',
  'Condensed': 'sans-serif-condensed',
  'Casual': 'casual',
};

class AppSettings extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  String fontName = 'پیش‌فرض';
  double textScale = 1.0; // 0.85 تا 1.6
  bool cabAlwaysDark = true;

  String? get fontFamily => kFonts[fontName];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values.elementAtOrNull(p.getInt('theme') ?? 0) ??
        ThemeMode.system;
    final f = p.getString('font') ?? 'پیش‌فرض';
    fontName = kFonts.containsKey(f) ? f : 'پیش‌فرض';
    textScale = (p.getDouble('scale') ?? 1.0).clamp(0.85, 1.6);
    cabAlwaysDark = p.getBool('cabDark') ?? true;
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme', themeMode.index);
    await p.setString('font', fontName);
    await p.setDouble('scale', textScale);
    await p.setBool('cabDark', cabAlwaysDark);
  }

  void update({ThemeMode? theme, String? font, double? scale, bool? cabDark}) {
    if (theme != null) themeMode = theme;
    if (font != null) fontName = font;
    if (scale != null) textScale = scale;
    if (cabDark != null) cabAlwaysDark = cabDark;
    notifyListeners();
    _save();
  }

  void reset() {
    themeMode = ThemeMode.system;
    fontName = 'پیش‌فرض';
    textScale = 1.0;
    cabAlwaysDark = true;
    notifyListeners();
    _save();
  }
}

class SettingsPage extends StatelessWidget {
  final AppSettings settings;
  const SettingsPage({super.key, required this.settings});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('تنظیمات')),
        body: ListView(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + adsBottomPad),
          children: [
            if (adsEnabled) const RemoveAdsTile(),
            if (adsEnabled) const SizedBox(height: 18),
            const Text('تم'),
            const SizedBox(height: 8),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('سیستم')),
                ButtonSegment(value: ThemeMode.light, label: Text('سفید')),
                ButtonSegment(value: ThemeMode.dark, label: Text('سیاه')),
              ],
              selected: {settings.themeMode},
              onSelectionChanged: (s) => settings.update(theme: s.first),
            ),
            const SizedBox(height: 24),
            const Text('فونت'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: settings.fontName,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(), isDense: true),
              items: [
                for (final k in kFonts.keys)
                  DropdownMenuItem(
                      value: k,
                      child: Text(k,
                          style: TextStyle(fontFamily: kFonts[k]))),
              ],
              onChanged: (v) => settings.update(font: v),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                  'فونت‌های فارسی همراه اپ‌اند. گزینه‌های انگلیسی (Sans-serif و...) از خود گوشی گرفته می‌شوند و ممکن است روی بعضی گوشی‌ها نباشند.',
                  style: TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 24),
            Text('اندازه‌ی فونت: ${(settings.textScale * 100).round()}٪'),
            Slider(
              value: settings.textScale,
              min: 0.85,
              max: 1.6,
              divisions: 15,
              label: '${(settings.textScale * 100).round()}٪',
              onChanged: (v) => settings.update(scale: v),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text('نمونه: قطار ۶۲۰ تهران ← یزد  ۲۲:۳۰  ۱۲۰ km/h'),
              ),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('صفحه‌ی کابین همیشه تیره باشد'),
              subtitle: const Text('مناسب لکوموتیورانی در شب'),
              value: settings.cabAlwaysDark,
              onChanged: (v) => settings.update(cabDark: v),
            ),
            ValueListenableBuilder<bool>(
              valueListenable: Access.unlocked,
              builder: (_, open, __) => open
                  ? ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.lock_outline_rounded),
                      title: const Text('قفل کردن بخش لکوموتیورانی'),
                      subtitle: const Text('دفعه‌ی بعد دوباره کد خواسته می‌شود'),
                      onTap: () => Access.lock(),
                    )
                  : const SizedBox.shrink(),
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.help_outline_rounded),
              title: const Text('راهنما'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const HelpPage())),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.chat_bubble_outline_rounded),
              title: const Text('ارسال نظر و پیشنهاد (ایتا)'),
              subtitle: const Directionality(
                  textDirection: TextDirection.ltr, child: Text(kSupportId)),
              onTap: () => openSupport(context),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('سیاست حریم خصوصی'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const PrivacyPage())),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: settings.reset,
              icon: const Icon(Icons.restore),
              label: const Text('بازگشت به تنظیمات پیش‌فرض'),
            ),
          ],
        ),
      ),
    );
  }
}


class RemoveAdsTile extends StatefulWidget {
  const RemoveAdsTile({super.key});

  @override
  State<RemoveAdsTile> createState() => _RemoveAdsTileState();
}

class _RemoveAdsTileState extends State<RemoveAdsTile> {
  bool _busy = false;

  Future<void> _act(bool alreadyOwned) async {
    if (_busy) return;
    setState(() => _busy = true);
    String message;
    try {
      if (alreadyOwned) {
        final owned = await ProPurchase.refresh();
        message = owned
            ? 'خرید حذف تبلیغات تأیید شد.'
            : 'خریدی برای این حساب بازار پیدا نشد.';
      } else {
        final success = await ProPurchase.buy();
        message = success
            ? 'خرید موفق بود؛ تبلیغات برای همیشه غیرفعال شد.'
            : 'خرید تأیید نشد. دوباره بررسی کنید.';
      }
    } catch (e) {
      message = e.toString().contains('PURCHASE_CANCELLED')
          ? 'خرید لغو شد.'
          : 'پرداخت انجام نشد یا ارتباط با کافه‌بازار برقرار نیست. لطفاً دوباره تلاش کنید.';
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: ProPurchase.isPro,
      builder: (context, owned, _) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(
                owned ? Icons.verified_rounded : Icons.block_rounded,
                color: owned ? Colors.green : Theme.of(context).colorScheme.primary,
                size: 30,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      owned ? 'تبلیغات حذف شده است' : 'حذف دائمی تبلیغات',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      owned
                          ? 'این خرید به‌صورت دائمی برای شما فعال است.'
                          : 'خرید یک‌باره از کافه‌بازار؛ بدون تمدید و پرداخت مجدد.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _busy
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : TextButton(
                      onPressed: () => _act(owned),
                      child: Text(owned ? 'بازیابی' : 'خرید'),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    const text = 'ریل‌پیما اطلاعات شخصی شما را (مثل نام، شماره تلفن یا موقعیت مکانی) جمع‌آوری یا ذخیره نمی‌کند.\n\n'
        '• تنظیمات اپ (تم، فونت و اندازه‌ی فونت) فقط روی گوشی خودتان ذخیره می‌شود.\n'
        '• برای به‌روزرسانی جدول‌ها، اپ فایل جدول‌ها را از اینترنت (GitHub) دانلود می‌کند و اطلاعاتی از شما نمی‌فرستد.\n'
        '• هنگام ورود به بخش لکوموتیورانی ممکن است تبلیغ ویدئویی تپسل نمایش داده شود؛ با خرید حذف دائمی تبلیغات، این تبلیغ غیرفعال می‌شود. تپسل ممکن است برای نمایش تبلیغ از شناسه‌ی تبلیغاتی دستگاه و اطلاعات فنی گوشی استفاده کند.\\n'
        '• بخش لکوموتیورانی با کد دسترسی باز می‌شود. برای بررسی کد، خودِ کد و یک شناسه‌ی تصادفی نصب به سرویس دسترسی اپ فرستاده می‌شود (نه نام، شماره یا موقعیت شما).\n\n'
        'اطلاعات جدول‌ها صرفاً کمکی است و جایگزین اعلام رسمی راه‌آهن نیست.';
    return Scaffold(
      appBar: AppBar(title: const Text('سیاست حریم خصوصی')),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Text(text, style: TextStyle(fontSize: 16, height: 1.8)),
      ),
    );
  }
}
