import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// فونت‌های همراه اپ (assets/fonts) و فونت‌های سیستمی اندروید.
/// وجود فونت‌های سیستمی به گوشی بستگی دارد؛ اگر نبود، فونت پیش‌فرض نمایش داده می‌شود.
const kFonts = <String, String?>{
  'پیش‌فرض': null,
  'هما': 'BHoma',
  'کامران': 'BKamran',
  'تیر': 'BTir',
  'کودک': 'BKoodak',
  'تیتر': 'BTitr',
  'Sans-serif': 'sans-serif',
  'Serif': 'serif',
  'Monospace': 'monospace',
  'Condensed': 'sans-serif-condensed',
  'Casual': 'casual',
};

class AppSettings extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  String fontName = 'پیش‌فرض';
  double textScale = 1.0; // 0.85 تا 1.6
  bool cabAlwaysDark = true;

  String? get fontFamily => kFonts[fontName];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values.elementAtOrNull(p.getInt('theme') ?? 0) ??
        ThemeMode.system;
    final f = p.getString('font') ?? 'پیش‌فرض';
    fontName = kFonts.containsKey(f) ? f : 'پیش‌فرض';
    textScale = (p.getDouble('scale') ?? 1.0).clamp(0.85, 1.6);
    cabAlwaysDark = p.getBool('cabDark') ?? true;
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme', themeMode.index);
    await p.setString('font', fontName);
    await p.setDouble('scale', textScale);
    await p.setBool('cabDark', cabAlwaysDark);
  }

  void update({ThemeMode? theme, String? font, double? scale, bool? cabDark}) {
    if (theme != null) themeMode = theme;
    if (font != null) fontName = font;
    if (scale != null) textScale = scale;
    if (cabDark != null) cabAlwaysDark = cabDark;
    notifyListeners();
    _save();
  }

  void reset() {
    themeMode = ThemeMode.system;
    fontName = 'پیش‌فرض';
    textScale = 1.0;
    cabAlwaysDark = true;
    notifyListeners();
    _save();
  }
}

class SettingsPage extends StatelessWidget {
  final AppSettings settings;
  const SettingsPage({super.key, required this.settings});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('تنظیمات')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('تم'),
            const SizedBox(height: 8),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('سیستم')),
                ButtonSegment(value: ThemeMode.light, label: Text('سفید')),
                ButtonSegment(value: ThemeMode.dark, label: Text('سیاه')),
              ],
              selected: {settings.themeMode},
              onSelectionChanged: (s) => settings.update(theme: s.first),
            ),
            const SizedBox(height: 24),
            const Text('فونت'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: settings.fontName,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(), isDense: true),
              items: [
                for (final k in kFonts.keys)
                  DropdownMenuItem(
                      value: k,
                      child: Text(k,
                          style: TextStyle(fontFamily: kFonts[k]))),
              ],
              onChanged: (v) => settings.update(font: v),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                  'فونت‌های فارسی همراه اپ‌اند. گزینه‌های انگلیسی (Sans-serif و...) از خود گوشی گرفته می‌شوند و ممکن است روی بعضی گوشی‌ها نباشند.',
                  style: TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 24),
            Text('اندازه‌ی فونت: ${(settings.textScale * 100).round()}٪'),
            Slider(
              value: settings.textScale,
              min: 0.85,
              max: 1.6,
              divisions: 15,
              label: '${(settings.textScale * 100).round()}٪',
              onChanged: (v) => settings.update(scale: v),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text('نمونه: قطار ۶۲۰ تهران ← یزد  ۲۲:۳۰  ۱۲۰ km/h'),
              ),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('صفحه‌ی کابین همیشه تیره باشد'),
              subtitle: const Text('مناسب لکوموتیورانی در شب'),
              value: settings.cabAlwaysDark,
              onChanged: (v) => settings.update(cabDark: v),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: settings.reset,
              icon: const Icon(Icons.restore),
              label: const Text('بازگشت به تنظیمات پیش‌فرض'),
            ),
          ],
        ),
      ),
    );
  }
}
