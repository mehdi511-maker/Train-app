import 'package:flutter/material.dart';

import 'models.dart';
import 'repository.dart';

void main() => runApp(const TrainApp());

class TrainApp extends StatelessWidget {
  const TrainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'برنامه قطارها',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final repo = Repository();
  Dataset? ds;
  bool updating = false;
  String from = '', to = '';
  int swapN = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final d = await repo.load();
    if (!mounted) return;
    setState(() => ds = d);
    if (await repo.shouldAutoCheck(d)) {
      await _update(silent: true);
    }
  }

  Future<void> _update({bool silent = false}) async {
    final cur = ds;
    if (cur == null || updating) return;
    setState(() => updating = true);
    final r = await repo.update(cur);
    if (!mounted) return;
    setState(() {
      updating = false;
      if (r.data != null) ds = r.data;
    });
    if (!silent || r.status == UpdateStatus.updated) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(r.message)));
    }
  }

  void _swap() => setState(() {
        final t = from;
        from = to;
        to = t;
        swapN++; // فیلدها با مقدار جدید دوباره ساخته می‌شوند
      });

  @override
  Widget build(BuildContext context) {
    final d = ds;
    return Scaffold(
      appBar: AppBar(
        title: const Text('برنامه قطارها'),
        actions: [
          updating
              ? const Padding(
                  padding: EdgeInsets.all(16),
                  child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2)))
              : IconButton(
                  tooltip: 'به‌روزرسانی جدول‌ها',
                  icon: const Icon(Icons.refresh),
                  onPressed: d == null ? null : () => _update(),
                ),
        ],
      ),
      body: d == null
          ? const Center(child: CircularProgressIndicator())
          : _body(d),
    );
  }

  Widget _body(Dataset d) {
    final results = search(d, from, to);
    final expired = d.isExpired();
    final stations = d.stations;
    return Column(
      children: [
        if (expired)
          MaterialBanner(
            backgroundColor: Theme.of(context).colorScheme.errorContainer,
            content: Text(
                'اعتبار جدول‌ها در ${fmtDate(d.validTo)} تمام شده است. برای دریافت جدول جدید به‌روزرسانی کنید.'),
            leading: const Icon(Icons.warning_amber),
            actions: [
              TextButton(
                  onPressed: updating ? null : () => _update(),
                  child: const Text('به‌روزرسانی'))
            ],
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: Row(children: [
            Expanded(
              child: Column(children: [
                StationField(
                    key: ValueKey('from$swapN'),
                    initial: from,
                    label: 'مبدأ (یا شماره قطار)',
                    icon: Icons.trip_origin,
                    options: stations,
                    onChanged: (v) => setState(() => from = v)),
                const SizedBox(height: 8),
                StationField(
                    key: ValueKey('to$swapN'),
                    initial: to,
                    label: 'مقصد (اختیاری)',
                    icon: Icons.place,
                    options: stations,
                    onChanged: (v) => setState(() => to = v)),
              ]),
            ),
            IconButton(
                tooltip: 'جابه‌جایی مبدأ و مقصد',
                icon: const Icon(Icons.swap_vert),
                onPressed: _swap),
          ]),
        ),
        Expanded(
          child: results.isEmpty
              ? Center(
                  child: Text(
                      norm(from).isEmpty && norm(to).isEmpty
                          ? 'نام ایستگاه یا شماره قطار را وارد کنید'
                          : 'قطاری پیدا نشد',
                      style: Theme.of(context).textTheme.bodyLarge))
              : ListView.builder(
                  itemCount: results.length,
                  itemBuilder: (_, k) => MatchTile(m: results[k]),
                ),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Text(
              'اعتبار جدول‌ها: ${fmtDate(d.validFrom)} تا ${fmtDate(d.validTo)}',
              style: Theme.of(context).textTheme.bodySmall),
        ),
      ],
    );
  }
}

class StationField extends StatelessWidget {
  final String label, initial;
  final IconData icon;
  final List<String> options;
  final ValueChanged<String> onChanged;
  const StationField(
      {super.key,
      this.initial = '',
      required this.label,
      required this.icon,
      required this.options,
      required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Autocomplete<String>(
      initialValue: TextEditingValue(text: initial),
      optionsBuilder: (v) {
        final q = norm(v.text);
        if (q.isEmpty) return const Iterable<String>.empty();
        return options.where((o) => norm(o).contains(q)).take(8);
      },
      onSelected: onChanged,
      fieldViewBuilder: (context, c, focus, _) => TextField(
        controller: c,
        focusNode: focus,
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: const OutlineInputBorder(),
          isDense: true,
          suffixIcon: c.text.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    c.clear();
                    onChanged('');
                  }),
        ),
      ),
    );
  }
}

String fmtDuration(int? m) {
  if (m == null) return '';
  final h = m ~/ 60, mm = m % 60;
  return h == 0 ? '$mm دقیقه' : (mm == 0 ? '$h ساعت' : '$h ساعت و $mm دقیقه');
}

class MatchTile extends StatelessWidget {
  final TripMatch m;
  const MatchTile({super.key, required this.m});

  @override
  Widget build(BuildContext context) {
    final t = m.train;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: ListTile(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => TrainPage(m: m))),
        title: Text('قطار ${t.number}  •  ${t.from} ← ${t.to}'),
        subtitle: Text(
            '${m.origin.station} ${m.departTime}  ⟵  ${m.dest.station} ${m.arriveTime}\n'
            '${t.days}${m.durationMin == null ? '' : '  •  ${fmtDuration(m.durationMin)}'}'),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}

class TrainPage extends StatelessWidget {
  final TripMatch m;
  const TrainPage({super.key, required this.m});

  @override
  Widget build(BuildContext context) {
    final t = m.train;
    final jj = m.j < 0 ? t.stops.length - 1 : m.j;
    return Scaffold(
      appBar: AppBar(title: Text('قطار ${t.number}')),
      body: Column(children: [
        ListTile(
          title: Text('${t.from} ← ${t.to}'),
          subtitle: Text(
              '${t.days}\nاعتبار: ${fmtDate(t.validFrom)} تا ${fmtDate(t.validTo)}'),
          isThreeLine: true,
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView.builder(
            itemCount: t.stops.length,
            itemBuilder: (_, k) {
              final s = t.stops[k];
              final inRange = k >= m.i && k <= jj;
              final times = [
                if (s.arrival != null) 'ورود ${s.arrival}',
                if (s.departure != null) 'حرکت ${s.departure}',
                if ((s.stopMin ?? 0) > 0) 'توقف ${s.stopMin} دقیقه',
              ].join('  •  ');
              return ListTile(
                dense: true,
                selected: inRange,
                leading: Text('${k + 1}'),
                title: Text(s.station),
                subtitle: Text(times),
                trailing: Text('${s.km} km'),
              );
            },
          ),
        ),
      ]),
    );
  }
}
