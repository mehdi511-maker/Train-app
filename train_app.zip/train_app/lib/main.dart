import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import 'access.dart';
import 'ads.dart';
import 'driver.dart' show clockToMin;
import 'driver_page.dart';
import 'help_page.dart';
import 'info_widgets.dart';
import 'models.dart';
import 'repository.dart';
import 'settings.dart';

const kBlue = Color(0xFF0B5FD8);
const kBlueDark = Color(0xFF0A3FA0);
const kBlueLight = Color(0xFF3B8BFF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = AppSettings();
  await settings.load();
  await Access.init();
  runApp(TrainApp(settings: settings));
  // تبلیغ بعد از بالا آمدن اپ مقداردهی می‌شود تا شروع اپ کند نشود
  Ads.init().then((_) => Ads.showBanner());
}

class TrainApp extends StatelessWidget {
  final AppSettings settings;
  const TrainApp({super.key, required this.settings});

  ThemeData _theme(Brightness b) => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: kBlue, brightness: b),
      fontFamily: settings.fontFamily);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) => MaterialApp(
        title: 'ریل‌پیما',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: settings.themeMode,
        builder: (context, child) {
          final mq = MediaQuery.of(context);
          final sys = mq.textScaler.scale(1);
          return MediaQuery(
            data: mq.copyWith(
                textScaler: TextScaler.linear(sys * settings.textScale)),
            child: Directionality(
                textDirection: TextDirection.rtl, child: child!),
          );
        },
        home: HomePage(settings: settings),
      ),
    );
  }
}

/// کارت گرد و تمیز با لبه‌ی ظریف
class AppCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final EdgeInsets margin;
  const AppCard(
      {super.key,
      required this.child,
      this.onTap,
      this.padding = const EdgeInsets.all(16),
      this.margin = const EdgeInsets.symmetric(horizontal: 14, vertical: 6)});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final r = BorderRadius.circular(22);
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: r,
        border: Border.all(color: cs.outlineVariant),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
            borderRadius: r,
            onTap: onTap,
            child: Padding(padding: padding, child: child)),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final AppSettings settings;
  const HomePage({super.key, required this.settings});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final repo = Repository();
  Dataset? ds;
  bool updating = false;
  String from = '', to = '';
  int swapN = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final d = await repo.load();
    if (!mounted) return;
    setState(() => ds = d);
    if (await repo.shouldAutoCheck(d)) {
      await _update(silent: true);
    }
  }

  Future<void> _update({bool silent = false}) async {
    final cur = ds;
    if (cur == null || updating) return;
    setState(() => updating = true);
    final r = await repo.update(cur);
    if (!mounted) return;
    setState(() {
      updating = false;
      if (r.data != null) ds = r.data;
    });
    if (!silent || r.status == UpdateStatus.updated) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(r.message)));
    }
  }

  void _swap() => setState(() {
        final t = from;
        from = to;
        to = t;
        swapN++; // فیلدها با مقدار جدید دوباره ساخته می‌شوند
      });

  @override
  Widget build(BuildContext context) {
    final d = ds;
    return Scaffold(
      body: d == null
          ? const Center(child: CircularProgressIndicator())
          : _body(d),
    );
  }

  Widget _header(Dataset d) {
    final top = MediaQuery.of(context).padding.top;
    final stations = d.stations;
    return Container(
      padding: EdgeInsets.fromLTRB(16, top + 10, 16, 18),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [kBlueDark, kBlue, kBlueLight]),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Column(children: [
        Row(children: [
          const Icon(Icons.train_rounded, color: Colors.white, size: 34),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('ریل‌پیما',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w800)),
              Text('جدول قطارهای مسافری',
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
            ]),
          ),
          IconButton(
              tooltip: 'راهنما',
              color: Colors.white,
              icon: const Icon(Icons.help_outline_rounded),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const HelpPage()))),
          IconButton(
              tooltip: 'تنظیمات',
              color: Colors.white,
              icon: const Icon(Icons.settings_rounded),
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => SettingsPage(settings: widget.settings)))),
          updating
              ? const Padding(
                  padding: EdgeInsets.all(14),
                  child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white)))
              : IconButton(
                  tooltip: 'به‌روزرسانی جدول‌ها',
                  color: Colors.white,
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: () => _update(),
                ),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            child: Column(children: [
              StationField(
                  key: ValueKey('from$swapN'),
                  initial: from,
                  label: 'مبدأ (یا شماره قطار)',
                  icon: Icons.trip_origin,
                  options: stations,
                  onChanged: (v) => setState(() => from = v)),
              const SizedBox(height: 10),
              StationField(
                  key: ValueKey('to$swapN'),
                  initial: to,
                  label: 'مقصد (اختیاری)',
                  icon: Icons.place_rounded,
                  options: stations,
                  onChanged: (v) => setState(() => to = v)),
            ]),
          ),
          const SizedBox(width: 8),
          Material(
            color: Colors.white24,
            shape: const CircleBorder(),
            child: IconButton(
                tooltip: 'جابه‌جایی مبدأ و مقصد',
                color: Colors.white,
                icon: const Icon(Icons.swap_vert_rounded),
                onPressed: _swap),
          ),
        ]),
      ]),
    );
  }

  Widget _body(Dataset d) {
    final results = search(d, from, to);
    final expired = d.isExpired();
    final cs = Theme.of(context).colorScheme;
    final empty = norm(from).isEmpty && norm(to).isEmpty;
    return Column(
      children: [
        _header(d),
        if (expired)
          AppCard(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Icon(Icons.warning_amber_rounded, color: cs.error),
              const SizedBox(width: 10),
              Expanded(
                  child: Text(
                      'اعتبار جدول‌ها در ${fmtDate(d.validTo)} تمام شده است. برای دریافت جدول جدید به‌روزرسانی کنید.')),
              TextButton(
                  onPressed: updating ? null : () => _update(),
                  child: const Text('به‌روزرسانی')),
            ]),
          ),
        Expanded(
          child: results.isEmpty
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(empty ? Icons.travel_explore_rounded : Icons.search_off_rounded,
                        size: 84, color: cs.primary.withOpacity(0.35)),
                    const SizedBox(height: 12),
                    Text(
                        empty
                            ? 'نام ایستگاه یا شماره قطار را وارد کنید'
                            : 'قطاری پیدا نشد',
                        style: Theme.of(context).textTheme.titleMedium),
                  ]),
                )
              : ListView.builder(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  itemCount: results.length,
                  itemBuilder: (_, k) =>
                      MatchTile(m: results[k], settings: widget.settings, ds: d),
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.fromLTRB(8, 4, 8, 6 + adsBottomPad),
            child: Text(
                'اعتبار جدول‌ها: ${fmtDate(d.validFrom)} تا ${fmtDate(d.validTo)}',
                style: Theme.of(context).textTheme.bodySmall),
          ),
        ),
      ],
    );
  }
}

class StationField extends StatelessWidget {
  final String label, initial;
  final IconData icon;
  final List<String> options;
  final ValueChanged<String> onChanged;
  const StationField(
      {super.key,
      this.initial = '',
      required this.label,
      required this.icon,
      required this.options,
      required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Autocomplete<String>(
      initialValue: TextEditingValue(text: initial),
      optionsBuilder: (v) {
        final q = norm(v.text);
        if (q.isEmpty) return const Iterable<String>.empty();
        return options.where((o) => norm(o).contains(q)).take(8);
      },
      onSelected: onChanged,
      fieldViewBuilder: (context, c, focus, _) => TextField(
        controller: c,
        focusNode: focus,
        onChanged: onChanged,
        style: const TextStyle(fontSize: 16),
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          filled: true,
          fillColor: Theme.of(context).colorScheme.surface,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          suffixIcon: c.text.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.clear_rounded),
                  onPressed: () {
                    c.clear();
                    onChanged('');
                  }),
        ),
      ),
    );
  }
}

String fmtDuration(int? m) {
  if (m == null) return '';
  final h = m ~/ 60, mm = m % 60;
  return h == 0 ? '$mm دقیقه' : (mm == 0 ? '$h ساعت' : '$h ساعت و $mm دقیقه');
}

class _Pill extends StatelessWidget {
  final String text;
  final Color bg, fg;
  final IconData? icon;
  const _Pill(this.text, {required this.bg, required this.fg, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 15, color: fg), const SizedBox(width: 4)],
        Flexible(
            child: Text(text,
                style: TextStyle(color: fg, fontSize: 12.5, fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

const _tabular = [FontFeature.tabularFigures()];

/// وضعیت لحظه‌ای سفر بین ایستگاه مبدأ و مقصد جستجو (فقط بر اساس ساعت امروز).
class _TripState {
  final bool started, arrived;
  final double progress; // ۰ تا ۱
  final int minutes; // قبل از حرکت: تا حرکت؛ در راه: تا رسیدن
  const _TripState(this.started, this.arrived, this.progress, this.minutes);
}

_TripState? _tripState(TripMatch m, DateTime now) {
  final dep = clockToMin(m.departTime);
  if (dep == null) return null;
  final dur = m.durationMin;
  final cur = now.hour * 60 + now.minute + now.second / 60.0;
  var el = cur - dep;
  if (dur == null || dur <= 0) {
    return _TripState(el >= 0, false, 0, 0);
  }
  if (el < 0 && el + 1440 < dur) el += 1440; // سفری که از دیروز شروع شده و هنوز در راه است
  if (el < 0) return _TripState(false, false, 0, (-el).ceil());
  if (el >= dur) return const _TripState(true, true, 1, 0);
  return _TripState(true, false, el / dur, (dur - el).ceil());
}

class MatchTile extends StatefulWidget {
  final TripMatch m;
  final AppSettings settings;
  final Dataset ds;
  const MatchTile(
      {super.key, required this.m, required this.settings, required this.ds});

  @override
  State<MatchTile> createState() => _MatchTileState();
}

class _MatchTileState extends State<MatchTile> {
  Timer? _timer;
  TripMatch get m => widget.m;
  AppSettings get settings => widget.settings;
  Dataset get ds => widget.ds;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Widget _dot(Color c) => Container(
        width: 11,
        height: 11,
        decoration: BoxDecoration(
            color: c,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: c.withOpacity(0.55), blurRadius: 6)]),
      );

  @override
  Widget build(BuildContext context) {
    final t = m.train;
    final today = todayJalali();
    final changes = ds.changesFor(t, today);
    final hasCancel = changes.any((c) => c.kind == 'cancel');
    final hasOther = changes.any((c) => c.kind != 'cancel');
    final cancelledNow = ds.cancelledToday(t, today);
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final timeStyle = tt.headlineSmall?.copyWith(
        fontWeight: FontWeight.w800, fontFeatures: _tabular);
    final trip = cancelledNow ? null : _tripState(m, DateTime.now());
    final green = Colors.green.shade600;
    final red = Colors.red.shade600;
    return AppCard(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => TrainPage(m: m, settings: settings, ds: ds))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
                color: cs.primaryContainer,
                borderRadius: BorderRadius.circular(12)),
            child: Text('قطار ${t.number}',
                style: TextStyle(
                    color: cs.onPrimaryContainer, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 10),
          Expanded(
              child: Text('${t.from} ← ${t.to}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: tt.bodySmall)),
          Icon(Icons.chevron_left_rounded, color: cs.outline),
        ]),
        const SizedBox(height: 14),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisSize: MainAxisSize.min, children: [
              if (cancelledNow)
                _dot(cs.outline)
              else if (trip != null)
                _dot(trip.started ? green : red),
              if (cancelledNow || trip != null) const SizedBox(width: 7),
              Text(m.departTime, style: timeStyle),
            ]),
            SizedBox(
                width: 96,
                child: Text(m.origin.station,
                    maxLines: 1, overflow: TextOverflow.ellipsis, style: tt.bodySmall)),
          ]),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4, left: 6, right: 6),
              child: Column(children: [
                Text(fmtDuration(m.durationMin),
                    style: tt.labelSmall?.copyWith(color: cs.outline)),
                Row(children: [
                  Expanded(child: Divider(color: cs.outlineVariant, thickness: 2)),
                  Icon(Icons.arrow_back_rounded, size: 16, color: cs.outline),
                ]),
              ]),
            ),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(m.arriveTime, style: timeStyle),
            SizedBox(
                width: 96,
                child: Text(m.dest.station,
                    textAlign: TextAlign.end,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodySmall)),
          ]),
        ]),
        if (trip != null) ...[
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: trip.progress,
              minHeight: 7,
              backgroundColor: cs.surfaceContainerHighest,
              valueColor: AlwaysStoppedAnimation(green),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            !trip.started
                ? (trip.minutes > 0
                    ? 'هنوز حرکت نکرده • ${fmtDuration(trip.minutes)} تا حرکت'
                    : 'هنوز حرکت نکرده')
                : trip.arrived
                    ? 'به مقصد رسیده'
                    : 'در راه • ${(trip.progress * 100).round()}٪ • ${fmtDuration(trip.minutes)} تا مقصد',
            style: tt.labelMedium?.copyWith(
                color: trip.started ? green : red, fontWeight: FontWeight.w700),
          ),
        ],
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 6, children: [
          _Pill(t.days,
              bg: cs.secondaryContainer,
              fg: cs.onSecondaryContainer,
              icon: Icons.calendar_month_rounded),
          if (cancelledNow)
            _Pill('امروز طبق نامه حذف شده',
                bg: cs.errorContainer, fg: cs.onErrorContainer, icon: Icons.cancel_rounded)
          else if (hasCancel)
            _Pill('در بعضی روزها حذف می‌شود',
                bg: cs.errorContainer,
                fg: cs.onErrorContainer,
                icon: Icons.event_busy_rounded)
          else if (hasOther)
            _Pill('تغییر برنامه دارد',
                bg: cs.tertiaryContainer,
                fg: cs.onTertiaryContainer,
                icon: Icons.info_outline_rounded),
        ]),
      ]),
    );
  }
}

class TrainPage extends StatelessWidget {
  final TripMatch m;
  final AppSettings settings;
  final Dataset ds;
  const TrainPage(
      {super.key, required this.m, required this.settings, required this.ds});

  Future<void> _openDriver(BuildContext context, Train t) async {
    if (!await requireAccess(context)) return;
    if (!context.mounted) return;
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => DriverPage(train: t, settings: settings, ds: ds)));
  }

  @override
  Widget build(BuildContext context) {
    final t = m.train;
    final jj = m.j < 0 ? t.stops.length - 1 : m.j;
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
          title: Text('قطار ${t.number}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          centerTitle: true),
      body: ListView(padding: EdgeInsets.only(bottom: 24 + adsBottomPad), children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${t.from} ← ${t.to}',
                style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(t.days, style: tt.bodyMedium),
            Text('اعتبار: ${fmtDate(t.validFrom)} تا ${fmtDate(t.validTo)}',
                style: tt.bodySmall?.copyWith(color: cs.outline)),
          ]),
        ),
        // دکمه‌ی درشت لکوموتیورانی
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          child: Material(
            borderRadius: BorderRadius.circular(26),
            elevation: 3,
            shadowColor: kBlue.withOpacity(0.4),
            child: Ink(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [kBlueDark, kBlue, kBlueLight]),
                borderRadius: BorderRadius.circular(26),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(26),
                onTap: () => _openDriver(context, t),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
                  child: Row(children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: const BoxDecoration(
                          color: Colors.white24, shape: BoxShape.circle),
                      child: const Icon(Icons.train_rounded,
                          color: Colors.white, size: 36),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('لکوموتیورانی',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 28,
                                    fontWeight: FontWeight.w900)),
                            SizedBox(height: 2),
                            Text('جدول مسیر، سرعت مجاز، کابین و محاسبه‌ی تأخیر',
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 13.5)),
                          ]),
                    ),
                    ValueListenableBuilder<bool>(
                      valueListenable: Access.unlocked,
                      builder: (_, open, __) => Icon(
                          open
                              ? Icons.chevron_left_rounded
                              : Icons.lock_outline_rounded,
                          color: Colors.white,
                          size: open ? 34 : 30),
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ),
        ChangesCard(train: t, ds: ds, expanded: true),
        const SizedBox(height: 8),
        for (var k = 0; k < t.stops.length; k++) _stopRow(context, t, k, jj),
      ]),
    );
  }

  Widget _stopRow(BuildContext context, Train t, int k, int jj) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final s = t.stops[k];
    final first = k == 0, last = k == t.stops.length - 1;
    final inRange = k >= m.i && k <= jj;
    final lineColor = inRange ? cs.primary : cs.outlineVariant;
    final details = [
      if ((s.stopMin ?? 0) > 0) 'توقف ${s.stopMin} دقیقه',
      if (s.note != null) s.note!,
    ].join('  •  ');
    return IntrinsicHeight(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          SizedBox(
            width: 52,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (s.arrival != null)
                  Text(s.arrival!,
                      style: tt.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w800, fontFeatures: _tabular)),
                if (s.departure != null && s.departure != s.arrival)
                  Text(s.departure!,
                      style: tt.bodySmall?.copyWith(
                          color: cs.outline, fontFeatures: _tabular)),
              ]),
            ),
          ),
          SizedBox(
            width: 26,
            child: Column(children: [
              Expanded(
                  child: Container(
                      width: 3, color: first ? Colors.transparent : lineColor)),
              Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: inRange ? cs.primary : cs.surface,
                  border: Border.all(color: lineColor, width: 3),
                ),
              ),
              Expanded(
                  child: Container(
                      width: 3, color: last ? Colors.transparent : lineColor)),
            ]),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.station,
                    style: tt.bodyLarge?.copyWith(
                        fontWeight: inRange ? FontWeight.w800 : FontWeight.w500)),
                if (details.isNotEmpty)
                  Text(details,
                      style: tt.bodySmall?.copyWith(color: cs.outline)),
              ]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text('${s.km} km',
                style: tt.bodySmall?.copyWith(color: cs.outline)),
          ),
        ]),
      ),
    );
  }
}
