import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'help_page.dart' show kSupportId, openSupport;

/// تابع فعال‌سازی Appwrite
const kAccessUrl = 'https://train-app.sgp.appwrite.run';

/// مهلت کارکرد بدون تأیید آنلاین
const kMaxOffline = Duration(days: 90);

/// مدت آزمایشی (ثانیه‌ی واقعاً مصرف‌شده داخل بخش لکوموتیورانی)
const kTrialSeconds = 120;


class _ApiReply {
  final Map<String, dynamic> data;
  final DateTime? serverDate;
  const _ApiReply(this.data, this.serverDate);
}

class Access {
  static final ValueNotifier<bool> unlocked = ValueNotifier(false);

  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _kCode = 'acc_appwrite_code';
  static const _kVerifiedServer = 'acc_verified_server_ms';
  static const _kVerifiedLocal = 'acc_verified_local_ms';
  static const _kLastSeenLocal = 'acc_last_seen_local_ms';
  static const _kDevice = 'acc_android_device_id';
  static const _kTrial = 'acc_trial_used_secure';

  static Future<String> _deviceId() async {
    var id = await _storage.read(key: _kDevice);

    // شناسه ذخیره‌شده فقط وقتی استفاده شود که با الگوی مجاز سرور مطابقت دارد.
    if (id != null &&
        RegExp(r'^[A-Za-z0-9_-]{8,128}$').hasMatch(id)) {
      return id;
    }

    final info = await DeviceInfoPlugin().androidInfo;
    final androidId = info.id.trim();

    if (androidId.isEmpty || androidId.toLowerCase() == 'unknown') {
      throw StateError('شناسه اندروید قابل دریافت نیست');
    }

    // تبدیل شناسه به Base64 URL-safe تا فقط نویسه‌های مجاز سرور تولید شود.
    final encoded = base64Url
        .encode(utf8.encode(androidId.toLowerCase()))
        .replaceAll('=', '');

    id = 'and_$encoded';

    if (!RegExp(r'^[A-Za-z0-9_-]{8,128}$').hasMatch(id)) {
      throw StateError('ساخت شناسه معتبر دستگاه ناموفق بود');
    }

    await _storage.write(key: _kDevice, value: id);
    return id;
  }

  static Future<int> trialLeft() async {
    final secure = await _storage.read(key: _kTrial);
    int used = int.tryParse(secure ?? '') ?? 0;

    // انتقال میزان مصرف آزمایشی نسخه‌های قبلی به فضای امن
    if (secure == null) {
      final p = await SharedPreferences.getInstance();
      used = p.getInt('acc_trial_used') ?? 0;
      await _storage.write(key: _kTrial, value: '$used');
    }
    return max(0, kTrialSeconds - used);
  }

  static Future<void> addTrialUsed(int seconds) async {
    if (seconds <= 0) return;
    final current = int.tryParse(await _storage.read(key: _kTrial) ?? '') ?? 0;
    final used = min(kTrialSeconds, current + seconds);
    await _storage.write(key: _kTrial, value: '$used');
  }

  static Future<_ApiReply?> _post(Map<String, dynamic> body) async {
    try {
      final res = await http
          .post(
            Uri.parse(kAccessUrl),
            headers: {'content-type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));

      final decoded = jsonDecode(utf8.decode(res.bodyBytes));
      if (decoded is! Map<String, dynamic>) return null;
      final dateHeader = res.headers['date'];
      DateTime? serverDate;
      if (dateHeader != null) serverDate = HttpDate.parse(dateHeader).toUtc();
      return _ApiReply(decoded, serverDate);
    } catch (_) {
      return null;
    }
  }

  static Future<void> _recordVerification(DateTime? serverDate) async {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch;
    final trusted = serverDate?.millisecondsSinceEpoch ?? now;
    await _storage.write(key: _kVerifiedServer, value: '$trusted');
    await _storage.write(key: _kVerifiedLocal, value: '$now');
    await _storage.write(key: _kLastSeenLocal, value: '$now');
    unlocked.value = true;
  }

  /// بررسی آفلاین با مهلت ۹۰ روز و کنترل عقب‌بردن ساعت گوشی.
  static Future<bool> check() async {
    final code = await _storage.read(key: _kCode);
    if (code == null || code.isEmpty) {
      unlocked.value = false;
      return false;
    }

    final verifiedServer = int.tryParse(
      await _storage.read(key: _kVerifiedServer) ?? '',
    );
    final verifiedLocal = int.tryParse(
      await _storage.read(key: _kVerifiedLocal) ?? '',
    );
    final lastSeen = int.tryParse(
      await _storage.read(key: _kLastSeenLocal) ?? '',
    );

    if (verifiedServer == null || verifiedLocal == null || lastSeen == null) {
      unlocked.value = false;
      return false;
    }

    final now = DateTime.now().toUtc().millisecondsSinceEpoch;

    // عقب‌بردن ساعت بیش از ۵ دقیقه باعث رد اعتبار محلی می‌شود.
    if (now < lastSeen - const Duration(minutes: 5).inMilliseconds ||
        now < verifiedLocal - const Duration(minutes: 5).inMilliseconds) {
      unlocked.value = false;
      return false;
    }

    final elapsed = now - verifiedLocal;
    final serverBasedNow = verifiedServer + elapsed;
    final withinOfflineWindow =
        elapsed >= 0 && elapsed <= kMaxOffline.inMilliseconds;

    // تاریخ مرجع سرور نیز نباید بیش از ۹۰ روز از آخرین تأیید فاصله بگیرد.
    final serverWindowOk =
        serverBasedNow - verifiedServer <= kMaxOffline.inMilliseconds;

    await _storage.write(key: _kLastSeenLocal, value: '$now');
    final ok = withinOfflineWindow && serverWindowOk;
    unlocked.value = ok;
    return ok;
  }

  static Future<void> init() async {
    await check();
    // اعتبارسنجی آنلاین در پس‌زمینه؛ در نبود اینترنت مهلت آفلاین حفظ می‌شود.
    refresh();
  }

  static Future<void> refresh() async {
    final code = await _storage.read(key: _kCode);
    if (code == null || code.isEmpty) return;

    String device;
    try {
      device = await _deviceId();
    } catch (_) {
      return;
    }

    final reply = await _post({
      'action': 'validate',
      'code': code,
      'device_id': device,
    });
    if (reply == null) return;

    if (reply.data['success'] == true) {
      await _recordVerification(reply.serverDate);
    } else {
      // پاسخ منفی معتبر از سرور یعنی کد نامعتبر، منقضی یا مسدود شده است.
      await _storage.delete(key: _kCode);
      await _storage.delete(key: _kVerifiedServer);
      await _storage.delete(key: _kVerifiedLocal);
      await _storage.delete(key: _kLastSeenLocal);
      unlocked.value = false;
    }
  }

  /// null یعنی موفق؛ در غیر این صورت متن خطا.
  static Future<String?> unlock(String code) async {
    final normalized = code.trim().toUpperCase();
    if (!RegExp(r'^\d{7,10}$|^[A-Za-z0-9-]{8,64}$').hasMatch(normalized)) return 'کد را کامل وارد کنید';

    String device;
    try {
      device = await _deviceId();
    } catch (_) {
      return 'شناسه دستگاه اندروید دریافت نشد؛ برنامه را دوباره اجرا کنید';
    }

    final reply = await _post({
      'action': 'activate',
      'code': normalized,
      'device_id': device,
    });
    if (reply == null) return 'برای فعال‌سازی باید اینترنت وصل باشد';

    if (reply.data['success'] != true) {
      final message = reply.data['message'];
      return message is String && message.isNotEmpty
          ? message
          : 'فعال‌سازی ناموفق بود؛ دوباره امتحان کنید';
    }

    await _storage.write(key: _kCode, value: normalized);
    await _recordVerification(reply.serverDate);
    return null;
  }

  static Future<void> lock() async {
    await _storage.delete(key: _kCode);
    await _storage.delete(key: _kVerifiedServer);
    await _storage.delete(key: _kVerifiedLocal);
    await _storage.delete(key: _kLastSeenLocal);
    unlocked.value = false;
  }
}

/// اگر قفل باز است یا هنوز زمان آزمایشی مانده true؛ وگرنه برگه‌ی ورود کد را نشان می‌دهد.
Future<bool> requireAccess(BuildContext context) async {
  if (await Access.check()) return true;
  if (await Access.trialLeft() > 0) return true;
  if (!context.mounted) return false;
  return showUnlockSheet(context);
}

Future<bool> showUnlockSheet(BuildContext context,
    {bool dismissible = true}) async {
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    isDismissible: dismissible,
    enableDrag: dismissible,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const _UnlockSheet(),
  );
  return ok == true;
}

class _UnlockSheet extends StatefulWidget {
  const _UnlockSheet();

  @override
  State<_UnlockSheet> createState() => _UnlockSheetState();
}

class _UnlockSheetState extends State<_UnlockSheet> {
  final _c = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await Access.unlock(_c.text);
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Material(
        color: cs.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        clipBehavior: Clip.antiAlias,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: cs.outlineVariant,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 22),
            Container(
              width: 80,
              height: 80,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF0A3FA0), Color(0xFF0B5FD8), Color(0xFF3B8BFF)]),
                boxShadow: [
                  BoxShadow(
                      color: Color(0x550B5FD8),
                      blurRadius: 20,
                      offset: Offset(0, 8))
                ],
              ),
              child: const Icon(Icons.lock_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(height: 16),
            Text('بخش لکوموتیورانی',
                style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('برای باز شدن قفل کد انحصاری را وارد کنید.',
                textAlign: TextAlign.center,
                style: tt.bodyLarge?.copyWith(color: cs.onSurfaceVariant)),
            const SizedBox(height: 20),
            Directionality(
              textDirection: TextDirection.ltr,
              child: TextField(
                controller: _c,
                autofocus: true,
                autocorrect: false,
                enableSuggestions: false,
                textCapitalization: TextCapitalization.characters,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    letterSpacing: 3, fontSize: 22, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: cs.surfaceContainerHighest,
                  hintText: 'کد انحصاری',
                  hintStyle: const TextStyle(letterSpacing: 0, fontSize: 16),
                  prefixIcon: const Icon(Icons.key_rounded),
                  errorText: _error,
                  errorMaxLines: 3,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none),
                ),
                onSubmitted: (_) => _submit(),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18))),
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5))
                    : const Text('باز کردن قفل',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              ),
            ),
            TextButton(
              onPressed: _busy ? null : () => Navigator.pop(context, false),
              child: const Text('انصراف'),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(20)),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.info_outline_rounded, color: cs.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('راهنما',
                        style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(
                        'کد انحصاری این اپ برای لکوموتیورانان ناحیه‌ی یزد تعریف شده است. '
                        'برای دریافت کد، از طریق ایتا با پشتیبان تماس بگیرید.',
                        style: tt.bodyMedium?.copyWith(height: 1.7)),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => openSupport(context),
                      icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                      label: const Directionality(
                          textDirection: TextDirection.ltr, child: Text(kSupportId)),
                    ),
                    const SizedBox(height: 6),
                    Text('فعال‌سازی بار اول به اینترنت نیاز دارد.',
                        style: tt.bodySmall?.copyWith(color: cs.outline)),
                  ]),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
