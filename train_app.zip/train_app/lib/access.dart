import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'help_page.dart' show kSupportId, openSupport;

/// ⚠️ آدرس سرویس Cloudflare Worker خودتان را اینجا بگذارید (بدون / آخر)
const kAccessUrl = 'https://railpeyma-access.ef58cipwmtcj7qjchrg88gd57.workers.dev';

/// اگر این‌قدر بدون تأیید آنلاین بگذرد، دوباره قفل می‌شود (برای لغو کدها).
const kMaxOffline = Duration(days: 14);

/// مدت آزمایشی (ثانیه‌ی واقعاً مصرف‌شده داخل بخش لکوموتیورانی)
const kTrialSeconds = 120;

const _reasons = {
  'invalid': 'کد نادرست است',
  'revoked': 'این کد لغو شده است',
  'expired': 'مهلت این کد تمام شده است',
  'device_limit': 'این کد روی تعداد مجاز گوشی فعال شده است؛ با سازنده‌ی اپ تماس بگیرید',
  'rate_limited': 'تلاش ناموفق زیاد بود؛ چند دقیقه بعد دوباره امتحان کنید',
};

class Access {
  /// آیا بخش لکوموتیورانی الان باز است؟ (برای نشان دادن قفل روی دکمه)
  static final ValueNotifier<bool> unlocked = ValueNotifier(false);

  static const _kToken = 'acc_token';
  static const _kVerified = 'acc_verified';
  static const _kDevice = 'acc_device';
  static const _kTrial = 'acc_trial_used';

  /// چند ثانیه از زمان آزمایشی مانده است.
  static Future<int> trialLeft() async {
    final p = await SharedPreferences.getInstance();
    return max(0, kTrialSeconds - (p.getInt(_kTrial) ?? 0));
  }

  static Future<void> addTrialUsed(int seconds) async {
    final p = await SharedPreferences.getInstance();
    final used = (p.getInt(_kTrial) ?? 0) + seconds;
    await p.setInt(_kTrial, min(kTrialSeconds, used));
  }

  /// شناسه‌ی تصادفی این نصب (اطلاعات شخصی نیست).
  static Future<String> _deviceId(SharedPreferences p) async {
    var d = p.getString(_kDevice);
    if (d == null) {
      final r = Random.secure();
      d = List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
      await p.setString(_kDevice, d);
    }
    return d;
  }

  /// null یعنی جواب JSON نگرفتیم (اینترنت/سرور در دسترس نیست).
  static Future<Map<String, dynamic>?> _post(
      String path, Map<String, dynamic> body) async {
    try {
      final res = await http
          .post(Uri.parse('$kAccessUrl$path'),
              headers: {'content-type': 'application/json'},
              body: jsonEncode(body))
          .timeout(const Duration(seconds: 12));
      final j = jsonDecode(utf8.decode(res.bodyBytes));
      return j is Map<String, dynamic> ? j : null;
    } catch (_) {
      return null;
    }
  }

  /// بدون اینترنت هم کار می‌کند: فقط به نشانه‌ی ذخیره‌شده و زمان آخرین تأیید نگاه می‌کند.
  static Future<bool> check() async {
    final p = await SharedPreferences.getInstance();
    final ok = p.getString(_kToken) != null &&
        DateTime.now().millisecondsSinceEpoch - (p.getInt(_kVerified) ?? 0) <=
            kMaxOffline.inMilliseconds;
    unlocked.value = ok;
    return ok;
  }

  /// موقع شروع اپ: وضعیت را می‌خواند و در پس‌زمینه از سرور تأیید می‌گیرد.
  static Future<void> init() async {
    await check();
    refresh();
  }

  /// از سرور می‌پرسد کد این گوشی هنوز معتبر است یا نه. اگر اینترنت نبود، چیزی عوض نمی‌شود.
  static Future<void> refresh() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString(_kToken);
    if (t == null) return;
    final j = await _post('/api/check', {'token': t});
    if (j == null) return;
    if (j['ok'] == true) {
      await p.setInt(_kVerified, DateTime.now().millisecondsSinceEpoch);
      unlocked.value = true;
    } else if (j['ok'] == false && j['reason'] != 'bad_request') {
      await p.remove(_kToken);
      unlocked.value = false;
    }
  }

  /// null یعنی موفق؛ در غیر این صورت متن خطا.
  static Future<String?> unlock(String code) async {
    if (code.trim().length < 6) return 'کد را کامل وارد کنید';
    final p = await SharedPreferences.getInstance();
    final j = await _post(
        '/api/verify', {'code': code.trim(), 'device': await _deviceId(p)});
    if (j == null) return 'برای فعال‌سازی باید اینترنت وصل باشد';
    if (j['ok'] != true) {
      return _reasons[j['reason']] ?? 'ورود ناموفق بود؛ دوباره امتحان کنید';
    }
    await p.setString(_kToken, j['token'] as String);
    await p.setInt(_kVerified, DateTime.now().millisecondsSinceEpoch);
    unlocked.value = true;
    return null;
  }

  static Future<void> lock() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kToken);
    unlocked.value = false;
  }
}

/// اگر قفل باز است یا هنوز زمان آزمایشی مانده true؛ وگرنه برگه‌ی ورود کد را نشان می‌دهد.
Future<bool> requireAccess(BuildContext context) async {
  if (await Access.check()) return true;
  if (await Access.trialLeft() > 0) return true;
  if (!context.mounted) return false;
  return showUnlockSheet(context);
}

Future<bool> showUnlockSheet(BuildContext context,
    {bool dismissible = true}) async {
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    isDismissible: dismissible,
    enableDrag: dismissible,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => const _UnlockSheet(),
  );
  return ok == true;
}

class _UnlockSheet extends StatefulWidget {
  const _UnlockSheet();

  @override
  State<_UnlockSheet> createState() => _UnlockSheetState();
}

class _UnlockSheetState extends State<_UnlockSheet> {
  final _c = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await Access.unlock(_c.text);
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Material(
        color: cs.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        clipBehavior: Clip.antiAlias,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: cs.outlineVariant,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 22),
            Container(
              width: 80,
              height: 80,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF0A3FA0), Color(0xFF0B5FD8), Color(0xFF3B8BFF)]),
                boxShadow: [
                  BoxShadow(
                      color: Color(0x550B5FD8),
                      blurRadius: 20,
                      offset: Offset(0, 8))
                ],
              ),
              child: const Icon(Icons.lock_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(height: 16),
            Text('بخش لکوموتیورانی',
                style: tt.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('برای باز شدن قفل کد انحصاری را وارد کنید.',
                textAlign: TextAlign.center,
                style: tt.bodyLarge?.copyWith(color: cs.onSurfaceVariant)),
            const SizedBox(height: 20),
            Directionality(
              textDirection: TextDirection.ltr,
              child: TextField(
                controller: _c,
                autofocus: true,
                autocorrect: false,
                enableSuggestions: false,
                textCapitalization: TextCapitalization.characters,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    letterSpacing: 3, fontSize: 22, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: cs.surfaceContainerHighest,
                  hintText: 'کد انحصاری',
                  hintStyle: const TextStyle(letterSpacing: 0, fontSize: 16),
                  prefixIcon: const Icon(Icons.key_rounded),
                  errorText: _error,
                  errorMaxLines: 3,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none),
                ),
                onSubmitted: (_) => _submit(),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                style: FilledButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18))),
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5))
                    : const Text('باز کردن قفل',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              ),
            ),
            TextButton(
              onPressed: _busy ? null : () => Navigator.pop(context, false),
              child: const Text('انصراف'),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: cs.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(20)),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.info_outline_rounded, color: cs.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('راهنما',
                        style: tt.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(
                        'کد انحصاری این اپ برای لکوموتیورانان ناحیه‌ی یزد تعریف شده است. '
                        'برای دریافت کد، از طریق ایتا با پشتیبان تماس بگیرید.',
                        style: tt.bodyMedium?.copyWith(height: 1.7)),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => openSupport(context),
                      icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                      label: const Directionality(
                          textDirection: TextDirection.ltr, child: Text(kSupportId)),
                    ),
                    const SizedBox(height: 6),
                    Text('فعال‌سازی بار اول به اینترنت نیاز دارد.',
                        style: tt.bodySmall?.copyWith(color: cs.outline)),
                  ]),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
