import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// ⚠️ آدرس سرویس Cloudflare Worker خودتان را اینجا بگذارید (بدون / آخر)
const kAccessUrl = 'https://railpeyma-access.ef58cipwmtcj7qjchrg88gd57.workers.dev';

/// اگر این‌قدر بدون تأیید آنلاین بگذرد، دوباره قفل می‌شود (برای لغو کدها).
const kMaxOffline = Duration(days: 14);

const _reasons = {
  'invalid': 'کد نادرست است',
  'revoked': 'این کد لغو شده است',
  'expired': 'مهلت این کد تمام شده است',
  'device_limit': 'این کد روی تعداد مجاز گوشی فعال شده است؛ با سازنده‌ی اپ تماس بگیرید',
  'rate_limited': 'تلاش ناموفق زیاد بود؛ چند دقیقه بعد دوباره امتحان کنید',
};

class Access {
  /// آیا بخش لکوموتیورانی الان باز است؟ (برای نشان دادن قفل روی دکمه)
  static final ValueNotifier<bool> unlocked = ValueNotifier(false);

  static const _kToken = 'acc_token';
  static const _kVerified = 'acc_verified';
  static const _kDevice = 'acc_device';

  /// شناسه‌ی تصادفی این نصب (اطلاعات شخصی نیست).
  static Future<String> _deviceId(SharedPreferences p) async {
    var d = p.getString(_kDevice);
    if (d == null) {
      final r = Random.secure();
      d = List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
      await p.setString(_kDevice, d);
    }
    return d;
  }

  /// null یعنی جواب JSON نگرفتیم (اینترنت/سرور در دسترس نیست).
  static Future<Map<String, dynamic>?> _post(
      String path, Map<String, dynamic> body) async {
    try {
      final res = await http
          .post(Uri.parse('$kAccessUrl$path'),
              headers: {'content-type': 'application/json'},
              body: jsonEncode(body))
          .timeout(const Duration(seconds: 12));
      final j = jsonDecode(utf8.decode(res.bodyBytes));
      return j is Map<String, dynamic> ? j : null;
    } catch (_) {
      return null;
    }
  }

  /// بدون اینترنت هم کار می‌کند: فقط به نشانه‌ی ذخیره‌شده و زمان آخرین تأیید نگاه می‌کند.
  static Future<bool> check() async {
    final p = await SharedPreferences.getInstance();
    final ok = p.getString(_kToken) != null &&
        DateTime.now().millisecondsSinceEpoch - (p.getInt(_kVerified) ?? 0) <=
            kMaxOffline.inMilliseconds;
    unlocked.value = ok;
    return ok;
  }

  /// موقع شروع اپ: وضعیت را می‌خواند و در پس‌زمینه از سرور تأیید می‌گیرد.
  static Future<void> init() async {
    await check();
    refresh();
  }

  /// از سرور می‌پرسد کد این گوشی هنوز معتبر است یا نه. اگر اینترنت نبود، چیزی عوض نمی‌شود.
  static Future<void> refresh() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString(_kToken);
    if (t == null) return;
    final j = await _post('/api/check', {'token': t});
    if (j == null) return;
    if (j['ok'] == true) {
      await p.setInt(_kVerified, DateTime.now().millisecondsSinceEpoch);
      unlocked.value = true;
    } else if (j['ok'] == false && j['reason'] != 'bad_request') {
      await p.remove(_kToken);
      unlocked.value = false;
    }
  }

  /// null یعنی موفق؛ در غیر این صورت متن خطا.
  static Future<String?> unlock(String code) async {
    if (code.trim().length < 6) return 'کد را کامل وارد کنید';
    final p = await SharedPreferences.getInstance();
    final j = await _post(
        '/api/verify', {'code': code.trim(), 'device': await _deviceId(p)});
    if (j == null) return 'برای فعال‌سازی باید اینترنت وصل باشد';
    if (j['ok'] != true) {
      return _reasons[j['reason']] ?? 'ورود ناموفق بود؛ دوباره امتحان کنید';
    }
    await p.setString(_kToken, j['token'] as String);
    await p.setInt(_kVerified, DateTime.now().millisecondsSinceEpoch);
    unlocked.value = true;
    return null;
  }

  static Future<void> lock() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kToken);
    unlocked.value = false;
  }
}

/// اگر قفل باز است true؛ وگرنه پنجره‌ی ورود کد را نشان می‌دهد.
Future<bool> requireAccess(BuildContext context) async {
  if (await Access.check()) return true;
  if (!context.mounted) return false;
  final ok = await showDialog<bool>(
      context: context, builder: (_) => const _UnlockDialog());
  return ok == true;
}

class _UnlockDialog extends StatefulWidget {
  const _UnlockDialog();

  @override
  State<_UnlockDialog> createState() => _UnlockDialogState();
}

class _UnlockDialogState extends State<_UnlockDialog> {
  final _c = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final err = await Access.unlock(_c.text);
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context, true);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(children: [
        Icon(Icons.lock_outline_rounded),
        SizedBox(width: 8),
        Text('بخش لکوموتیورانی'),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('این بخش فقط با کد دسترسی باز می‌شود. کد را وارد کنید '
            '(فقط بار اول و با اینترنت لازم است).'),
        const SizedBox(height: 14),
        Directionality(
          textDirection: TextDirection.ltr,
          child: TextField(
            controller: _c,
            autofocus: true,
            autocorrect: false,
            enableSuggestions: false,
            textCapitalization: TextCapitalization.characters,
            textAlign: TextAlign.center,
            style: const TextStyle(letterSpacing: 2, fontSize: 20),
            decoration: InputDecoration(
              border: const OutlineInputBorder(),
              hintText: 'XXXXX-XXXXX',
              errorText: _error,
              errorMaxLines: 3,
            ),
            onSubmitted: (_) => _submit(),
          ),
        ),
      ]),
      actions: [
        TextButton(
            onPressed: _busy ? null : () => Navigator.pop(context, false),
            child: const Text('انصراف')),
        FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('ورود')),
      ],
    );
  }
}
