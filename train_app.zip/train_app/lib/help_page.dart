import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'ads.dart';

const kSupportId = '@customer_services';
const kSupportUrl = 'https://eitaa.com/customer_services';

/// باز کردن گفت‌وگوی پشتیبانی در ایتا؛ اگر نشد، آیدی کپی می‌شود.
Future<void> openSupport(BuildContext context) async {
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(kSupportUrl),
        mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok) {
    await Clipboard.setData(const ClipboardData(text: kSupportId));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('ایتا باز نشد. آیدی کپی شد؛ در ایتا جستجو کنید: $kSupportId')));
    }
  }
}

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});

  static const _items = <(IconData, String, String)>[
    (
      Icons.search_rounded,
      'جستجوی قطار',
      'در کادر اول نام ایستگاه مبدأ (یا شماره‌ی قطار) و در کادر دوم مقصد را بنویسید؛ مقصد اختیاری است. '
          'با دکمه‌ی ⇅ مبدأ و مقصد جابه‌جا می‌شوند. نتیجه‌ها بر اساس ساعت حرکت مرتب‌اند و برای هر قطار '
          'ساعت حرکت، ساعت رسیدن، مدت سفر و تناوب (همه‌روزه، یک روز در میان و...) دیده می‌شود.'
    ),
    (
      Icons.timeline_rounded,
      'صفحه‌ی قطار',
      'با لمس هر نتیجه، همه‌ی ایستگاه‌های قطار به شکل خط زمانی با ساعت ورود و حرکت، توقف و کیلومتر باز '
          'می‌شود. بخشی از مسیر که جستجو کرده‌اید پررنگ است.'
    ),
    (
      Icons.event_busy_rounded,
      'تغییرات و حذف قطار',
      'اگر طبق نامه‌های ابلاغی قطاری در بعضی روزها حذف یا ساعتش عوض شده باشد، در نتیجه‌ی جستجو برچسب هشدار '
          'می‌بینید و در صفحه‌ی قطار کارت «تغییرات برنامه» با تاریخ‌ها باز می‌شود. اگر امروز در فهرست حذف باشد، '
          'کارت قرمز می‌شود. تاریخ‌های گذشته نمایش داده نمی‌شوند.'
    ),
    (
      Icons.train_rounded,
      'لکوموتیورانی',
      'دکمه‌ی بزرگ «لکوموتیورانی» در صفحه‌ی هر قطار دو بخش دارد:\n'
          '• جدول مسیر: برای هر ایستگاه ساعت‌ها، کیلومتر رسمی و واقعی، فاصله تا ایستگاه بعد، زمان قطعه و '
          'سرعت مجاز. فلش سبز یا قرمز یعنی سرعت مجاز بالا یا پایین می‌رود. علامت ⚠ یعنی برای آن قطعه دو '
          'سرعت ثبت شده و مقدار کمتر ملاک محاسبه است. توضیح ایستگاه (تلاقی، نماز، سوختگیری و...) زیر نامش '
          'می‌آید و بخش «نحوه راهبری» منطقه و نوع راهبری قطار را نشان می‌دهد.\n'
          '• کابین: ایستگاه بعد با شمارش معکوس زنده، سرعت مجاز فعلی و بعدی. صفحه روشن می‌ماند و تم تیره است.'
    ),
    (
      Icons.timer_outlined,
      'تأخیر و جبران در کابین',
      'تأخیر را با دکمه‌های + و − وارد کنید (⟲ برای صفر کردن). اپ میانگین سرعت لازم برای رسیدن طبق برنامه '
          'تا ایستگاه بعد و تا مقصد را حساب می‌کند. برای قطارهای بیش از ۲۴ ساعت (مثل ۵۸۷) «روز سفر» را '
          'انتخاب کنید، چون ساعت گوشی به‌تنهایی روز سفر را نمی‌گوید.'
    ),
    (
      Icons.refresh_rounded,
      'به‌روزرسانی جدول‌ها',
      'جدول‌ها داخل اپ ذخیره‌اند و بدون اینترنت هم کار می‌کنند. وقتی اعتبار جدول تمام شود، یا هر ۲۴ ساعت، '
          'اپ خودش اطلاعات جدید را از اینترنت می‌گیرد. با دکمه‌ی ⟳ بالای صفحه هم می‌توانید دستی به‌روزرسانی کنید.'
    ),
    (
      Icons.settings_rounded,
      'تنظیمات',
      'تم سفید، سیاه یا سیستم، انتخاب فونت، اندازه‌ی فونت و تیره بودن همیشگی صفحه‌ی کابین را از چرخ‌دنده تنظیم کنید.'
    ),
    (
      Icons.warning_amber_rounded,
      'نکته‌ی مهم',
      'این اپ مرجع کمکی است و جایگزین علائم، دستورالعمل‌ها و ابلاغ‌های رسمی راه‌آهن نیست. محدودیت‌های موقت '
          'سرعت و تغییرات لحظه‌ای در جدول نیست و محاسبه‌های کابین (بدون احتساب شتاب و ترمز) تقریبی‌اند. '
          'برای تصمیم عملیاتی همیشه به منبع رسمی مراجعه کنید.'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
          title: const Text('راهنما',
              style: TextStyle(fontWeight: FontWeight.w800)),
          centerTitle: true),
      body: ListView(
        padding: EdgeInsets.fromLTRB(14, 8, 14, 24 + adsBottomPad),
        children: [
          Card(
            elevation: 0,
            color: cs.primaryContainer,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.chat_bubble_outline_rounded, color: cs.onPrimaryContainer),
                  const SizedBox(width: 8),
                  Text('ارسال نظر و پیشنهاد',
                      style: tt.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800, color: cs.onPrimaryContainer)),
                ]),
                const SizedBox(height: 8),
                Text(
                    'نظر، پیشنهاد یا گزارش اشتباه در ساعت‌ها و اطلاعات قطارها را در ایتا برای ما بفرستید.',
                    style: TextStyle(color: cs.onPrimaryContainer)),
                const SizedBox(height: 10),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: SelectableText(kSupportId,
                      style: tt.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800, color: cs.onPrimaryContainer)),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  FilledButton.icon(
                      onPressed: () => openSupport(context),
                      icon: const Icon(Icons.send_rounded),
                      label: const Text('باز کردن در ایتا')),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(const ClipboardData(text: kSupportId));
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('آیدی کپی شد')));
                        }
                      },
                      icon: const Icon(Icons.copy_rounded),
                      label: const Text('کپی آیدی')),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          for (final (icon, title, body) in _items)
            Card(
              elevation: 0,
              clipBehavior: Clip.antiAlias,
              color: cs.surfaceContainerLow,
              margin: const EdgeInsets.symmetric(vertical: 4),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                  side: BorderSide(color: cs.outlineVariant)),
              child: ExpansionTile(
                shape: const Border(),
                collapsedShape: const Border(),
                leading: Icon(icon, color: cs.primary),
                title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                expandedCrossAxisAlignment: CrossAxisAlignment.start,
                children: [Text(body, style: const TextStyle(height: 1.7))],
              ),
            ),
        ],
      ),
    );
  }
}
