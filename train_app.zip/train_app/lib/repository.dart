import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// ⚠️ این آدرس را با ریپوی خودتان عوض کنید:
/// https://raw.githubusercontent.com/mehdi511-maker/train-app/<BRANCH>/assets/timetables.json
const kDataUrl =
    'https://raw.githubusercontent.com/mehdi511-maker/train-app/main/assets/timetables.json';

/// حداقل فاصله بین دو بررسی خودکار وقتی هنوز منقضی نشده.
/// فایل کوچک نسخه: {"valid_to": "1405/12/24", "data_version": 2}
/// با هر تغییر در timetables.json (جدول، تغییرات نامه، راهبری) data_version را یکی بالا ببرید.
const kVersionUrl =
    'https://raw.githubusercontent.com/mehdi511-maker/train-app/main/assets/version.json';

const kCheckEvery = Duration(hours: 24);

enum UpdateStatus { updated, alreadyLatest, failed }

class UpdateResult {
  final UpdateStatus status;
  final String message;
  final Dataset? data;
  UpdateResult(this.status, this.message, [this.data]);
}

class Repository {
  Future<File> _cacheFile() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/timetables.json');
  }

  /// داده‌ی جدیدتر بین نسخه‌ی کش‌شده و نسخه‌ی همراه اپ را برمی‌گرداند.
  Future<Dataset> load() async {
    final bundled =
        Dataset.parse(await rootBundle.loadString('assets/timetables.json'));
    try {
      final f = await _cacheFile();
      if (await f.exists()) {
        final cached = Dataset.parse(await f.readAsString());
        if (!bundled.isNewerThan(cached)) return cached;
      }
    } catch (_) {
      // کش خراب است؛ از نسخه‌ی همراه اپ استفاده می‌کنیم.
    }
    return bundled;
  }

  /// آیا زمان بررسی خودکار رسیده؟ (منقضی شده یا ۲۴ ساعت از آخرین بررسی گذشته)
  Future<bool> shouldAutoCheck(Dataset current) async {
    if (current.isExpired()) return true;
    final p = await SharedPreferences.getInstance();
    final last = p.getInt('lastCheck') ?? 0;
    return DateTime.now().millisecondsSinceEpoch - last >
        kCheckEvery.inMilliseconds;
  }

  /// ابتدا فایل کوچک version.json را می‌خواند؛ فقط اگر جدیدتر بود فایل اصلی را می‌گیرد.
  /// اگر version.json در دسترس نبود، مستقیم فایل اصلی را بررسی می‌کند.
  Future<UpdateResult> update(Dataset current) async {
    try {
      final remote = await _remoteVersion();
      if (remote != null &&
          remote.validTo <= current.validTo &&
          remote.dataVersion <= current.dataVersion) {
        final p = await SharedPreferences.getInstance();
        await p.setInt('lastCheck', DateTime.now().millisecondsSinceEpoch);
        return UpdateResult(UpdateStatus.alreadyLatest,
            'جدول‌ها به‌روز هستند (اعتبار تا ${fmtDate(current.validTo)})', current);
      }
      final res = await http
          .get(Uri.parse(kDataUrl))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        return UpdateResult(
            UpdateStatus.failed, 'خطای سرور (کد ${res.statusCode})');
      }
      final body = utf8.decode(res.bodyBytes);
      final fresh = Dataset.parse(body); // اگر نامعتبر باشد استثنا می‌دهد

      final p = await SharedPreferences.getInstance();
      await p.setInt('lastCheck', DateTime.now().millisecondsSinceEpoch);

      if (!fresh.isNewerThan(current)) {
        return UpdateResult(UpdateStatus.alreadyLatest,
            'جدول‌ها به‌روز هستند (اعتبار تا ${fmtDate(current.validTo)})', current);
      }
      final f = await _cacheFile();
      final tmp = File('${f.path}.tmp');
      await tmp.writeAsString(body, flush: true);
      await tmp.rename(f.path);
      return UpdateResult(UpdateStatus.updated,
          'اطلاعات جدید دریافت شد (اعتبار تا ${fmtDate(fresh.validTo)})', fresh);
    } on SocketException {
      return UpdateResult(UpdateStatus.failed, 'اتصال اینترنت برقرار نیست');
    } on FormatException catch (e) {
      return UpdateResult(UpdateStatus.failed, 'فایل دریافتی نامعتبر بود: ${e.message}');
    } catch (e) {
      return UpdateResult(UpdateStatus.failed, 'به‌روزرسانی ناموفق بود');
    }
  }

  /// محتوای version.json: تاریخ انقضا و شماره‌ی نسخه‌ی داده، یا null اگر در دسترس/معتبر نبود.
  Future<({int validTo, int dataVersion})?> _remoteVersion() async {
    try {
      final res = await http
          .get(Uri.parse(kVersionUrl))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;
      final j = jsonDecode(utf8.decode(res.bodyBytes));
      final v = dateToInt((j['valid_to'] ?? '').toString());
      if (v == 0) return null;
      return (validTo: v, dataVersion: (j['data_version'] as num?)?.toInt() ?? 0);
    } on SocketException {
      rethrow; // اینترنت نیست؛ تلاش دوم فایده ندارد
    } catch (_) {
      return null;
    }
  }
}
