import 'dart:async';

import 'package:flutter/foundation.dart' show ValueNotifier;

import 'package:cafebazaar_billing/cafebazaar_billing.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// خرید دائمی حذف تبلیغات از کافه‌بازار.
class ProPurchase {
  static const String productId = 'pro_unlock';

  // کلید عمومی RSA دریافتی از پنل کافه‌بازار؛ کلید خصوصی نیست.
  static const String _rsaPublicKey = 'MIHNMA0GCSqGSIb3DQEBAQUAA4G7ADCBtwKBrwDHs6wR2LW//F9IdDNMuHZBW/Sebk+7z4MeYVWkk9pL33+iBFzDeAc/akphNM84QRCOuzmkjoxsABpKo3xv4cd4DqvW/4XCneL9S5RkuxQc3/Szg3cfHdvWdSc9WYYJPgBoiHLt0Y+po/pkC1uhli/5CF+hOpovxHaBOzM8iEmsjEIaN7svzpWj+rXs8PXIiwmpi2cuJpR1cgWzOY+JK5uFojRwnK4tQfnxzAfvmLECAwEAAQ==';

  static final ValueNotifier<bool> isPro = ValueNotifier<bool>(false);

  static bool _connected = false;
  static Future<void>? _connecting;
  static const _cacheKey = 'pro_remove_ads_owned';

  /// ابتدا وضعیت ذخیره‌شده را سریع می‌خواند، سپس مالکیت واقعی را از بازار بازیابی می‌کند.
  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    isPro.value = prefs.getBool(_cacheKey) ?? false;

    try {
      await _ensureConnected().timeout(const Duration(seconds: 5));
      await refresh().timeout(const Duration(seconds: 5));
    } catch (_) {
      // اگر بازار در دسترس نبود، وضعیت آخرین خرید موفق حفظ می‌شود.
    }
  }

  static Future<void> _ensureConnected() async {
    if (_connected) return;
    if (_connecting != null) return _connecting!;

    final completer = Completer<void>();
    _connecting = completer.future;
    try {
      await CafeBazaarBilling.connect(
        _rsaPublicKey,
        onSucceed: () {
          _connected = true;
          if (!completer.isCompleted) completer.complete();
        },
        onFailed: () {
          _connected = false;
          if (!completer.isCompleted) {
            completer.completeError(StateError('اتصال به کافه‌بازار برقرار نشد'));
          }
        },
        onDisconnected: () {
          _connected = false;
        },
      );
      await completer.future.timeout(const Duration(seconds: 5));
    } finally {
      _connecting = null;
    }
  }

  static Future<void> _setOwned(bool value) async {
    isPro.value = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_cacheKey, value);
  }

  /// استعلام خرید غیرمصرفی؛ این محصول نباید consume شود.
  static Future<bool> refresh() async {
    await _ensureConnected();
    final info = await CafeBazaarBilling.queryPurchasedProduct(productId);
    final owned = info != null &&
        info.productId == productId &&
        info.purchaseState == PurchaseState.PURCHASED;
    await _setOwned(owned);
    return owned;
  }

  /// خرید یک‌باره حذف تبلیغات.
  static Future<bool> buy() async {
    await _ensureConnected();
    final info = await CafeBazaarBilling.purchase(productId);
    final success = info.productId == productId &&
        info.purchaseState == PurchaseState.PURCHASED;
    if (success) await _setOwned(true);
    return success;
  }
}
