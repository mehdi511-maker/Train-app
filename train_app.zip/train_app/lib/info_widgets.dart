import 'package:flutter/material.dart';

import 'models.dart';

const _months = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند'
];

/// [5, 9, 17 آبان • 1 آذر] از روی تاریخ‌های ۸ رقمی (مثل 14050805)
String fmtDays(List<int> dates) {
  final byMonth = <int, List<int>>{};
  for (final d in dates) {
    final m = (d ~/ 100) % 100;
    final key = (d ~/ 10000) * 100 + m;
    byMonth.putIfAbsent(key, () => []).add(d % 100);
  }
  final parts = <String>[];
  for (final key in byMonth.keys.toList()..sort()) {
    final m = key % 100;
    final name = (m >= 1 && m <= 12) ? _months[m - 1] : '$m';
    parts.add('${byMonth[key]!.join('، ')} $name');
  }
  return parts.join('  •  ');
}

String _kindTitle(ChangeItem c) {
  switch (c.kind) {
    case 'cancel':
      return c.direction == 'outbound' ? 'حذف (فقط رفت)' : 'حذف (رفت و برگشت)';
    case 'retime':
      return 'تغییر ساعت حرکت ${c.oldTime ?? ''} ← ${c.newTime ?? ''}';
    case 'extend':
      return 'ادامه سیر (سفر اضافه)';
    case 'formation':
      return 'تغییر ترکیب قطار';
    case 'origin_change':
      return 'تغییر ایستگاه مبدأ';
    default:
      return 'تغییر برنامه';
  }
}

/// تغییرات ابلاغی (حذف، تغییر ساعت و...) برای یک قطار؛ فقط موارد تمام‌نشده.
class ChangesCard extends StatelessWidget {
  final Train train;
  final Dataset ds;
  final bool expanded;
  const ChangesCard(
      {super.key, required this.train, required this.ds, this.expanded = false});

  @override
  Widget build(BuildContext context) {
    final today = todayJalali();
    final items = ds.changesFor(train, today);
    if (items.isEmpty) return const SizedBox.shrink();
    final cancelled = ds.cancelledToday(train, today);
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: cancelled ? cs.errorContainer : cs.tertiaryContainer,
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: ExpansionTile(
        initiallyExpanded: expanded || cancelled,
        leading: Icon(cancelled ? Icons.cancel : Icons.warning_amber),
        title: Text(
            cancelled
                ? 'امروز طبق نامه، این قطار حذف شده است'
                : 'تغییرات برنامه (${items.length} مورد)',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(ds.changesTitle.isEmpty
            ? 'طبق نامه‌ی ابلاغی'
            : 'طبق نامه‌ی ابلاغی: ${ds.changesTitle}'),
        children: [
          for (final c in items)
            ListTile(
              dense: true,
              title: Text('قطار ${c.train} • ${_kindTitle(c)}'),
              subtitle: Text([
                if (c.dates.isNotEmpty) fmtDays(c.dates),
                c.text,
              ].join('\n')),
              isThreeLine: true,
            ),
        ],
      ),
    );
  }
}

/// نحوه راهبری قطار (از جدول ابلاغی اداره کل نحوه راهبری).
class OpsCard extends StatelessWidget {
  final Train train;
  final Dataset ds;
  const OpsCard({super.key, required this.train, required this.ds});

  @override
  Widget build(BuildContext context) {
    final ops = ds.opsFor(train);
    if (ops.isEmpty) return const SizedBox.shrink();
    final expired = ds.opsValidTo != 0 && todayJalali() > ds.opsValidTo;
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: ExpansionTile(
        leading: const Icon(Icons.account_tree_outlined),
        title: const Text('نحوه راهبری',
            style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
            ds.opsValidTo == 0
                ? ds.opsTitle
                : '${ds.opsTitle} (معتبر تا ${fmtDate(ds.opsValidTo)})'
                    '${expired ? ' • منقضی شده' : ''}',
            style: TextStyle(color: expired ? cs.error : null)),
        children: [
          for (final e in ops)
            ListTile(
              dense: true,
              title: Text('منطقه ${e.region}'),
              subtitle: Text(
                  '${e.mode}${e.section == null ? '' : ' • ${e.section}'}'),
            ),
          if (ds.opsNote.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Text(ds.opsNote, style: Theme.of(context).textTheme.bodySmall),
            ),
        ],
      ),
    );
  }
}
