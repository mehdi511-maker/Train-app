import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('راهنمای ریل‌پیما'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _section(context, Icons.search_rounded, 'جستجوی قطار', [
            'در کادر «مبدأ (یا شماره قطار)» نام ایستگاه مبدأ یا شماره قطار را وارد کنید.',
            'برای محدودکردن نتایج، مقصد را هم در کادر دوم بنویسید.',
            'با دکمه جابه‌جایی، مبدأ و مقصد را عوض کنید.',
          ]),
          _section(context, Icons.route_rounded, 'مشاهده مسیر و جزئیات', [
            'روی کارت هر قطار بزنید تا ساعت حرکت، زمان سفر و ایستگاه‌های مسیر را ببینید.',
            'در صفحه جزئیات قطار، گزینه «لکوموتیورانی» اطلاعات مسیر و امکانات مربوط به رانندگی را باز می‌کند.',
          ]),
          _section(context, Icons.sync_rounded, 'به‌روزرسانی جدول‌ها', [
            'برای دریافت آخرین جدول‌ها، علامت تازه‌سازی بالای صفحه اصلی را لمس کنید.',
            'تاریخ اعتبار جدول‌ها در پایین صفحه اصلی نمایش داده می‌شود. اطلاعات برنامه را با اطلاعیه‌های رسمی راه‌آهن هم تطبیق دهید.',
          ]),
          _section(context, Icons.settings_rounded, 'تنظیمات', [
            'از بخش تنظیمات می‌توانید تم روشن یا تیره، فونت و اندازه نوشته‌ها را تغییر دهید.',
            'گزینه «صفحه کابین همیشه تیره باشد» برای استفاده در محیط کم‌نور در نظر گرفته شده است.',
          ]),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.support_agent_rounded, color: cs.primary, size: 26),
                  const SizedBox(width: 8),
                  Text('ارسال نظر و پشتیبانی', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 8),
                const Text('برای پیشنهاد، گزارش خطا یا پرسیدن سؤال، از طریق ایتا با پشتیبانی ریل‌پیما در ارتباط باشید.'),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => _openEitaa(context),
                    icon: const Icon(Icons.send_rounded),
                    label: const Text('ارتباط با پشتیبانی در ایتا'),
                  ),
                ),
                const SizedBox(height: 6),
                Center(child: SelectableText('@customer_services', style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700))),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  static Widget _section(BuildContext context, IconData icon, String title, List<String> lines) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(icon, color: cs.primary), const SizedBox(width: 8), Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          for (var i = 0; i < lines.length; i++)
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${i + 1}.  ', style: TextStyle(color: cs.primary, fontWeight: FontWeight.bold)),
                Expanded(child: Text(lines[i], style: const TextStyle(height: 1.6))),
              ]),
            ),
        ]),
      ),
    );
  }

  static Future<void> _openEitaa(BuildContext context) async {
    final uri = Uri.parse('https://eitaa.com/customer_services');
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بازکردن ایتا ممکن نشد؛ شناسه @customer_services را در ایتا جستجو کنید.')));
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای ارتباط، شناسه @customer_services را در ایتا جستجو کنید.')));
      }
    }
  }
}
