import 'package:flutter/services.dart';

/// کلید برنامه و شناسه‌ی زون بنر از پنل تپسل.
/// (این مقدارها محرمانه نیستند؛ تبلیغ‌دهنده‌ها هم داخل اپ می‌بینندشان.)
/// برای خاموش کردن تبلیغ، یکی از دو مقدار را خالی بگذارید.
const kTapsellAppKey =
    'idmebrhsdqqfmfldfejttnanopepqpoblmobophgtseqcmpntarsckbmqkbkncdfnjstit';
const kBannerZoneId = '6ae4e2c77ae48b79af14cf45';

/// فقط وقتی ساخت با «--dart-define=ADS=true» انجام شود (Run workflow ← ads) تبلیغ فعال است.
const kAdsBuild = bool.fromEnvironment('ADS', defaultValue: false);

bool get adsEnabled =>
    kAdsBuild && kTapsellAppKey.isNotEmpty && kBannerZoneId.isNotEmpty;

/// ارتفاع بنر ۳۲۰×۵۰ (برای فاصله‌ی پایین صفحه‌ها تا چیزی زیر بنر نماند)
const kBannerHeight = 56.0;
double get adsBottomPad => adsEnabled ? kBannerHeight : 0;

const _channel = MethodChannel('railpeyma/ads');

/// بنر تپسل با SDK بومی اندروید (فایل‌های android_native/ در ساخت کپی می‌شوند).
/// بنر یک نمای بومی روی کل اپ است؛ پس در صفحه‌های لکوموتیورانی پنهانش می‌کنیم.
class Ads {
  static bool _ready = false;

  static Future<void> init() async {
    if (!adsEnabled) return;
    try {
      _ready = (await _channel.invokeMethod<bool>('init', {'key': kTapsellAppKey})) ?? false;
    } catch (_) {
      _ready = false; // مثلاً روی پلتفرم‌های غیر اندروید
    }
  }

  static Future<void> showBanner() async {
    if (!_ready) return;
    try {
      await _channel.invokeMethod('showBanner', {'zone': kBannerZoneId});
    } catch (_) {}
  }

  static Future<void> hideBanner() async {
    if (!_ready) return;
    try {
      await _channel.invokeMethod('hideBanner');
    } catch (_) {}
  }
}
