package __PKG__

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var bridge: TapsellBridge? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val b = TapsellBridge(this)
        bridge = b
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "railpeyma/ads")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "init" -> result.success(b.init(call.argument<String>("key") ?: ""))
                    "showBanner" -> {
                        b.showBanner(call.argument<String>("zone") ?: "")
                        result.success(true)
                    }
                    "hideBanner" -> {
                        b.hideBanner()
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
