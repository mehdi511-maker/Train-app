package __PKG__;

import android.app.Activity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import ir.tapsell.plus.*;
import ir.tapsell.plus.model.*;

/** پل ساده‌ی Flutter به SDK بومی تپسل پلاس (فقط بنر استاندارد ۳۲۰×۵۰). */
public class TapsellBridge {
    private static final String TAG = "TapsellBridge";
    private final Activity activity;
    private FrameLayout container;
    private String responseId;
    private boolean requesting = false;
    private boolean visible = false;
    private boolean initialized = false;

    public TapsellBridge(Activity activity) {
        this.activity = activity;
    }

    /** مقداردهی SDK. امضای دقیق initialize بین نسخه‌ها فرق می‌کند، پس با reflection پیدایش می‌کنیم. */
    public boolean init(String key) {
        try {
            Method with2 = null, with3 = null;
            for (Method m : TapsellPlus.class.getMethods()) {
                if (!m.getName().equals("initialize")) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length >= 2 && p[0].isAssignableFrom(activity.getClass()) && p[1] == String.class) {
                    if (p.length == 2) with2 = m;
                    else if (p.length == 3) with3 = m;
                }
            }
            if (with2 != null) {
                with2.invoke(null, activity, key);
            } else if (with3 != null) {
                Class<?> lc = with3.getParameterTypes()[2];
                Object listener = null;
                if (lc.isInterface()) {
                    listener = Proxy.newProxyInstance(lc.getClassLoader(), new Class<?>[]{lc},
                            new InvocationHandler() {
                                @Override
                                public Object invoke(Object proxy, Method method, Object[] args) {
                                    Log.d(TAG, "init callback: " + method.getName());
                                    Class<?> r = method.getReturnType();
                                    if (r == boolean.class) return Boolean.FALSE;
                                    if (r == int.class) return Integer.valueOf(0);
                                    if (r == long.class) return Long.valueOf(0L);
                                    return null;
                                }
                            });
                }
                with3.invoke(null, activity, key, listener);
            } else {
                Log.e(TAG, "TapsellPlus.initialize not found");
                return false;
            }
            initialized = true;
            return true;
        } catch (Throwable t) {
            Log.e(TAG, "init failed", t);
            return false;
        }
    }

    private void ensureContainer() {
        if (container != null) return;
        container = new FrameLayout(activity);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        activity.addContentView(container, lp);
    }

    public void showBanner(final String zone) {
        visible = true;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ensureContainer();
                    container.setVisibility(View.VISIBLE);
                    if (!initialized || responseId != null || requesting || zone.isEmpty()) return;
                    requesting = true;
                    TapsellPlus.requestStandardBannerAd(activity, zone,
                            TapsellPlusBannerType.BANNER_320x50,
                            new AdRequestCallback() {
                                @Override
                                public void response(TapsellPlusAdModel model) {
                                    super.response(model);
                                    requesting = false;
                                    responseId = model.getResponseId();
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            TapsellPlus.showStandardBannerAd(activity, responseId, container,
                                                    new AdShowListener() {
                                                        @Override
                                                        public void onOpened(TapsellPlusAdModel m) {
                                                            super.onOpened(m);
                                                        }

                                                        @Override
                                                        public void onError(TapsellPlusErrorModel e) {
                                                            super.onError(e);
                                                            Log.e(TAG, "banner show error");
                                                        }
                                                    });
                                            container.setVisibility(visible ? View.VISIBLE : View.GONE);
                                        }
                                    });
                                }

                                @Override
                                public void error(@androidx.annotation.NonNull String message) {
                                    requesting = false;
                                    Log.e(TAG, "banner request error: " + message);
                                }
                            });
                } catch (Throwable t) {
                    requesting = false;
                    Log.e(TAG, "showBanner failed", t);
                }
            }
        });
    }

    public void hideBanner() {
        visible = false;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (container != null) container.setVisibility(View.GONE);
            }
        });
    }
}
